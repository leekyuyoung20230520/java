package com.example.demo;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.board.QuestionService;

@SpringBootTest
class SpringBootProjectApplicationTests {
	@Autowired
	private QuestionService questionService;

	@Test
	void contextLoads() {
		for (int i = 1; i < 500; i++) {
			String subject = String.format("테스트 데이터 %03d", i);
			String content = String.format("테스트 데이터 %03d 의 세부내용입니다.", i);
			questionService.create(subject, content,null);
		}
	}

}
