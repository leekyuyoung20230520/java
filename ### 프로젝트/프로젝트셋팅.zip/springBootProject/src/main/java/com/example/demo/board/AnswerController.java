package com.example.demo.board;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.user.SiteUser;
import com.example.demo.user.UserService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/answer")
public class AnswerController {
	@Autowired
	private QuestionService questionService;
	
	@Autowired
	private AnswerService answerService;
	
	@Autowired
	private UserService userService;
	
	@PreAuthorize("isAuthenticated()")
	@PostMapping("/create/{id}")
	public String answer(Model model, 
			@PathVariable("id") Integer id,
			@Valid AnswerForm answerForm, BindingResult bindingResult,
			Principal principal		// 로그인한 사용자에 대한 정보를 취득	
			) {
		Question question = questionService.detail(id);
		
		if(bindingResult.hasErrors()) {
			model.addAttribute("question",question);
			return "board/question_detail";
		}		
		SiteUser siteUser = userService.getUser(principal.getName());
		answerService.create(question,answerForm.getContent(), siteUser);
		return String.format("redirect:/question/detail/%s", id);
	}

}
