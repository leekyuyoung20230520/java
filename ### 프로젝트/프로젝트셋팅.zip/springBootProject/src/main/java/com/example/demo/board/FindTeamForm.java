package com.example.demo.board;

import com.example.demo.user.SiteUser;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FindTeamForm {
	private String id;
	
	@NotEmpty(message = "제목은 필수사항 입니다.")
	@Size(max=200)
	private String subject;
	
	
	@NotEmpty(message = "내용은 필수사항 입니다.")
	private String content;	
	
	private SiteUser author;
}
