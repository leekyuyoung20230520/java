package com.example.demo.board;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.DataNotFoundException;
import com.example.demo.user.SiteUser;

//@RequiredArgsConstructor
@Service
public class QuestionService {
	@Autowired
	private QuestionRepository qeustionRepository;  // 자동주입
	public Page<Question> getList(int page){
		List<Sort.Order> sorts = new ArrayList<>();
		sorts.add(Sort.Order.desc("createDate")); // 내림차순으로 정렬
		Pageable pageable = PageRequest.of(page, 10, Sort.by(sorts));
		return qeustionRepository.findAll(pageable);
	}
	
	
	public Question detail(Integer id) {
		Optional<Question> oq = qeustionRepository.findById(id);
		if(oq.isPresent())
			return oq.get();
		else
			throw new DataNotFoundException("questioni not found");		
	}


	public void create(String subject, String content, SiteUser siteUser) {
		Question q = new Question();
		q.setSubject(subject);
		q.setContent(content);
		q.setAuthor(siteUser);
		qeustionRepository.save(q);
	}
	
	public void modify(Question question, String subject, String content) {		
		question.setSubject(subject);
		question.setContent(content);
		question.setModifyDate(LocalDateTime.now());
//		question.setCreateDate(LocalDateTime.now());
		qeustionRepository.save(question);
	}


	public void delete(Question question) {
		qeustionRepository.delete(question);		
	}

}
