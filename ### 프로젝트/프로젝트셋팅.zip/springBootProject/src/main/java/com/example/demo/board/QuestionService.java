package com.example.demo.board;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DataNotFoundException;

//@RequiredArgsConstructor
@Service
public class QuestionService {
	@Autowired
	private QuestionRepository qeustionRepository;  // 자동주입
	public List<Question> getList(){
		return qeustionRepository.findAll();
	}
	
	
	public Question detail(Integer id) {
		Optional<Question> oq = qeustionRepository.findById(id);
		if(oq.isPresent())
			return oq.get();
		else
			throw new DataNotFoundException("questioni not found");		
	}


	public void create(String subject, String content) {
		Question q = new Question();
		q.setSubject(subject);
		q.setContent(content);
		qeustionRepository.save(q);
	}
}
