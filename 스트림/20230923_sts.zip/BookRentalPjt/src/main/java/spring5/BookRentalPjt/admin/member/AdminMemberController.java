package spring5.BookRentalPjt.admin.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/admin")
public class AdminMemberController {
	
	@Autowired
	private AdminMemberService adminService;

	@RequestMapping(value = {"","/"}, method = RequestMethod.GET)
	public String home() {
		System.out.println("AdminHomeController -- home");
		String nextPage = "admin/home";
		return nextPage;
	}
	
	// 관리자 회원가입 화면  - 처음에 화면을 보여준다..(양식을 보여준다)
	@RequestMapping(value = "/member/createAccountForm", method = RequestMethod.GET)
	public String createAccountForm() {
		System.out.println("AdminHomeController -- createAccountForm");
		String nextPage = "admin/member/create_account_form";
		return nextPage;
	}
	
	@PostMapping(value = "/member/createAccountConfirm")
	public String createAccountConfirm(AdminMemberVo vo) {
		System.out.println("AdminMemberController -- : \n" + vo + "\n----------");
		String nextPage = "admin/member/create_account_ok";
		int result =  adminService.createAccountConfirm(vo);
		if(result <=0) {
			nextPage = "admin/member/create_account_ng"; 
		}
		return nextPage;
	}
	
	// 로그인 폼 호출 - get방식
	@GetMapping("/member/loginForm")
	public String loginForm() {
		System.out.println("AdminMemberController--- loginForm");
		String nextPage = "admin/member/login_form";
		return nextPage;
	}
	// 로그인 처리
	@PostMapping("/member/loginConfirm")
	public String loginConfirm(AdminMemberVo vo) {
		System.out.println("AdminMemberController---loginConfirm");
		String nextPage = "admin/member/login_ok";
		
		AdminMemberVo loginedAdminMemberVo =  adminService.loginConfirm(vo);
		if(loginedAdminMemberVo == null)
			nextPage = "admin/member/login_ng";
		return nextPage;
	}
}
