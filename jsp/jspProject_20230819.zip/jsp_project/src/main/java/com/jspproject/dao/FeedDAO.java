package com.jspproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.jspproject.conn.ConnectionPool;
import com.jspproject.object.FeedObj;

public class FeedDAO {
	public List<FeedObj> getList() {
		List<FeedObj> list = new ArrayList<FeedObj>();
		String sql = "select * from feed";
		try (

				Connection conn = ConnectionPool.get();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();
			) 
		{
			while (rs.next()) {
				FeedObj obj = new FeedObj(rs.getString("id"), rs.getString("content"), rs.getString("ts"));
				list.add(obj);
			}
			
		} catch (Exception e) {	}
		
		return list;
	}
}
