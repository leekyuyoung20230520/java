package com.jspproject.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jspproject.conn.ConnectionPool;

public class UserDAO {
	public Connection conn = null;
	public PreparedStatement pstmt = null;
	public ResultSet rs = null;
	
	public boolean exists(String id) {
		boolean isTrue = false;
		try {					
			conn = ConnectionPool.get();
			String sql = "select * from user where id = ?";
			pstmt =  conn.prepareStatement(sql);
			// index start 1.....(not 0)
			pstmt.setString(1, id);						
			rs =  pstmt.executeQuery();
			if(rs.next()) isTrue =  true;				
			pstmt.close();conn.close();			
		}
		catch (Exception e) {}
		return isTrue;
	}
	public boolean delete(String id, String password) {		
		boolean isTrue = false;
		try {					
			conn = ConnectionPool.get();
			String sql = "select * from user where id = ? and password = ?";
			pstmt =  conn.prepareStatement(sql);
			pstmt.setString(1, id);pstmt.setString(2, password);
			rs =  pstmt.executeQuery();
			if(rs.next()){
				sql = "delete from user where id = ?";
				pstmt =  conn.prepareStatement(sql);
				pstmt.setString(1, id);
				int result = pstmt.executeUpdate();
				if(result > 0) isTrue =  true;
			}									
		}catch (Exception e) {
			try {
				rs.close();	pstmt.close();conn.close();
			}catch (Exception e2) {}			
		}
		return isTrue;
	}
	
	public boolean update(String id, String password, String name) {
		boolean isTrue = false;
		try {
			conn = ConnectionPool.get();
			String sql = "update user set password=?,name=?,ts = now() where id = ?;";
			PreparedStatement pstmt =  conn.prepareStatement(sql);
			// index start 1.....(not 0)		
			pstmt.setString(1, password);pstmt.setString(2, name);pstmt.setString(3, id);						
			int result = pstmt.executeUpdate();
			if(result > 0) isTrue = true; 
			pstmt.close();conn.close();			
		} catch (Exception e) {
			isTrue = false;
		}
		return isTrue;
	}
	public boolean isLogin(String id, String password) {
		boolean isTrue = false;
		try {
			conn = ConnectionPool.get();
			String sql = "select * from user where id = ? and password = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);pstmt.setString(2, password);
			rs = pstmt.executeQuery();
			if(rs.next()) isTrue = true;
		}catch (Exception e) {}
		return isTrue;
	}
}
