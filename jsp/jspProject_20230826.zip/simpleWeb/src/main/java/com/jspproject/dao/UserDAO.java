package com.jspproject.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.jspproject.conn.ConnectionPool;

public class UserDAO {

	public static boolean isLogin(String id,String password) {	

		
		
		String sql = "select * from user where id=? and password=?";	
		boolean isTrue = false;
		try(
			Connection conn = ConnectionPool.get();
			PreparedStatement pstmt =  conn.prepareStatement(sql);				
				)
		{
			pstmt.setString(1, id);pstmt.setString(2, password);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
				isTrue =  true;
		}catch (Exception e) {}
		
		return isTrue;		
	}
}
