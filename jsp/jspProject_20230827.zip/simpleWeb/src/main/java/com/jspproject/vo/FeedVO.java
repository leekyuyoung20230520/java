package com.jspproject.vo;

// VO 또는  DTO는 데이블의 데이터를 객체화
// 맴버변수는 컬럼명들...
// 생성자,  get/set, toString() 정도 있으면 된다
public class FeedVO {

	private int no;
	private String id;
	private String content;
	private String ts;
	private String images;
	private byte[] ufile;
	private String isUpdate;
	
	public FeedVO(String id) {this.id = id;}
	public FeedVO(int no, String id, String content, String ts, String images) {
		super();
		this.no = no;
		this.id = id;
		this.content = content;
		this.ts = ts;
		this.images = images;
	}
	public FeedVO(int no, String id, String content, String ts, String images,byte[] ufile) {
		super();
		this.no = no;
		this.id = id;
		this.content = content;
		this.ts = ts;
		this.images = images;
		this.ufile = ufile;
	}
	

	public String getIsUpdate() {
		return isUpdate;
	}
	public void setIsUpdate(String isUpdate) {
		this.isUpdate = isUpdate;
	}
	public byte[] getUfile() {
		return ufile;
	}
	public void setUfile(byte[] ufile) {
		this.ufile = ufile;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getTs() {
		return ts;
	}
	public void setTs(String ts) {
		this.ts = ts;
	}
	public String getImages() {
		return images;
	}
	public void setImages(String images) {
		this.images = images;
	}
	@Override
	public String toString() {
		return "FeedVO [no=" + no + ", id=" + id + ", content=" + content + ", ts=" + ts + ", images=" + images + "]";
	}
	
}
