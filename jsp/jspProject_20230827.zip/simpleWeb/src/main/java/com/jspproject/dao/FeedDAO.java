package com.jspproject.dao;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.jspproject.conn.ConnectionPool;
import com.jspproject.util.FileUtil;
import com.jspproject.vo.FeedVO;

public class FeedDAO {
	public static void updateFeed(FeedVO vo) {
		try {
			Connection conn = ConnectionPool.get();
			String sql = "update feed set content=?, images=?, ts=now() where no = ?;";
			PreparedStatement pstmt = conn.prepareStatement(sql);			
			pstmt.setString(1, vo.getContent());
			pstmt.setString(2, vo.getImages());
			pstmt.setInt(3, vo.getNo());	
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void insertFeed(FeedVO vo) {

		try {
			
			Connection conn = ConnectionPool.get();
			String sql = "insert into feed(id,content,images) values(?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getId());
			pstmt.setString(2, vo.getContent());
			pstmt.setString(3, vo.getImages());
			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static FeedVO multiPart(HttpServletRequest request, String root)
			throws FileUploadException, UnsupportedEncodingException, IOException {
		FeedVO vo = new FeedVO(null);
		
		ServletFileUpload sfu = new ServletFileUpload(new DiskFileItemFactory());
		List<FileItem> items = sfu.parseRequest(request);
		sfu.setHeaderEncoding("UTF-8"); // 요청 헤더의 인코딩 설정
		Iterator<FileItem> iter = items.iterator();
		while (iter.hasNext()) {			
			FileItem item = (FileItem) iter.next();
			String name = item.getFieldName();			
			if (item.isFormField()) {
				String value = item.getString("utf-8");				
				if (name.equals("no"))
					vo.setNo(Integer.valueOf(value));
				else if (name.equals("content"))
					vo.setContent(value);
				else if (name.equals("isUpdate"))
					vo.setIsUpdate(value);					
			} else {				
				if (name.equals("image")) {
					String fname = item.getName();	
					if(fname.isEmpty())
						return vo;
					vo.setImages(fname);
					byte[] ufile = item.get();					
					FileUtil.saveImage(root, fname, ufile);
				}
			}
		}
		return vo;
	}

	public static FeedVO getFeedById(String no) {
		// 1 DB 접속
		String sql = "select * from feed where no = ?";
		ResultSet rs = null;
		try (Connection conn = ConnectionPool.get(); PreparedStatement pstmt = conn.prepareStatement(sql);) {
			pstmt.setString(1, no);
			rs = pstmt.executeQuery();
			if (!rs.next()) // DB를 조회했는데 값이 없다
				return null;
			int ino = rs.getInt("no");
			String id = rs.getString("id");
			String content = rs.getString("content");
			String ts = rs.getString("ts");
			String images = rs.getString("images");
			FeedVO vo = new FeedVO(ino, id, content, ts, images);
			return vo;
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 2. 아이디로 feed테이블 검색해서 데이터 추출
		// 3. FeedVO 객체로 만들고
		// 4. 린턴
		return null;
	}
}
