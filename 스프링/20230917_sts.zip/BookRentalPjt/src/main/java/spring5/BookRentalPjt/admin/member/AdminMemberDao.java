package spring5.BookRentalPjt.admin.member;

//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

//@Component
@Repository
public class AdminMemberDao {

	public boolean isAdminMember(String a_m_id) {
		// TODO Auto-generated method stub
		return false;
	}

	public int insertAdminMemberAccount(AdminMemberVo vo) {
		// TODO Auto-generated method stub
		return 0;
	}

}
