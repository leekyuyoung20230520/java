package pjt_01;

public class MyCalculator {

	public void calAdd(int i, int j) throws Exception {
		ICalculator calcaulator = new CallAdd();
		int value = calcaulator.doOperation(i,j);
		System.out.println("result : " + value);
		
	}
	
	public void calSub(int i, int j) throws Exception {
		ICalculator calcaulator = new CallSub();
		int value = calcaulator.doOperation(i,j);
		System.out.println("result : " + value);		
	}
	
	public void calMul(int i, int j) throws Exception {
		ICalculator calcaulator = new CallMul();
		int value = calcaulator.doOperation(i,j);
		System.out.println("result : " + value);		
	}
	
	public void calDiv(int i, int j) throws Exception {
		ICalculator calcaulator = new CallDiv();
		int value = calcaulator.doOperation(i,j);
		System.out.println("result : " + value);		
	}

}
