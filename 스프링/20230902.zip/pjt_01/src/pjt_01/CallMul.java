package pjt_01;

public class CallMul implements ICalculator {

	@Override
	public int doOperation(int i, int j) {		
		return i * j;
	}

}
