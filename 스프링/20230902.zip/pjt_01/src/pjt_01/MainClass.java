package pjt_01;

public class MainClass {

	public static void main(String[] args) throws Exception {
		MyCalculator calculator = new MyCalculator();
		calculator.calAdd(10,5);
		calculator.calDiv(10,5);
		calculator.calMul(10,5);
		calculator.calSub(10,5);
	}

}
