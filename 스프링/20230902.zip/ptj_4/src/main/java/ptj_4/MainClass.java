package ptj_4;

public class MainClass {
	public static void main(String[] args) {
		TransfortationWalk tw = new TransfortationWalk();
		tw.move();
	}
}
