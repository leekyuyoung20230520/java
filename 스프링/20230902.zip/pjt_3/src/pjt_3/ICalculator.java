package pjt_3;

public interface ICalculator {

	int doOperation(int i, int j) throws Exception;

}
