package pjt_3;

public class MainClass {

	public static void main(String[] args) throws Exception {
//		MyCalculator calculator = new MyCalculator();
//		calculator.calAdd(10,5,new CallAdd() );
//		calculator.calDiv(10,5, new CallDiv() );
//		calculator.calMul(10,5, new CallMul() );
//		calculator.calSub(10,5, new CallSub() );
		// main에서 하던 일은 CallAssembler에서 하게됨
		new CallAssembler();
	}

}
