package pjt_3;
// 객체를 생성하고 주입하는 역활
// IoC 컨터이너 : 객체를 생성하고 조립하는 특별한 공간
// 빈 Bean : Ioc컨터에너의 객체
public class CallAssembler {
	// 맴버변수
	MyCalculator calculator;
	CallAdd calAdd;
	CallSub calSub;
	CallMul calMul;
	CallDiv calDiv;
	
	//  기본생성자 생성자
	public CallAssembler() {
		calculator = new MyCalculator();
		calAdd = new CallAdd();
		calSub = new CallSub();
		calMul = new CallMul();
		calDiv = new CallDiv();
		
		assemble();
	}
	// 맴버함수
	public void assemble() {
		try {
			calculator.calAdd(10,5,calAdd );
			calculator.calDiv(10,5, calDiv );
			calculator.calMul(10,5, calMul );
			calculator.calSub(10,5, calSub );
		}catch (Exception e) {}
	}
}
