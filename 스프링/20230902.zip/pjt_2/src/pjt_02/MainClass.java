package pjt_02;

public class MainClass {

	public static void main(String[] args) throws Exception {
		MyCalculator calculator = new MyCalculator();
		calculator.calAdd(10,5,new CallAdd() );
		calculator.calDiv(10,5, new CallDiv() );
		calculator.calMul(10,5, new CallMul() );
		calculator.calSub(10,5, new CallSub() );
	}

}
