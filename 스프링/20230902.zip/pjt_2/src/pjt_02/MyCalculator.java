package pjt_02;

public class MyCalculator {

	public void calAdd(int i, int j, ICalculator calc) throws Exception {		
		int value = calc.doOperation(i,j);
		System.out.println("result : " + value);		
	}
	
	public void calSub(int i, int j, ICalculator calc) throws Exception {
		int value = calc.doOperation(i,j);
		System.out.println("result : " + value);		
	}
	
	public void calMul(int i, int j, ICalculator calc) throws Exception {
		int value = calc.doOperation(i,j);
		System.out.println("result : " + value);		
	}
	
	public void calDiv(int i, int j,ICalculator calc) throws Exception {
		int value = calc.doOperation(i,j);
		System.out.println("result : " + value);		
	}

}
