package pjt_02;

public interface ICalculator {

	int doOperation(int i, int j) throws Exception;

}
