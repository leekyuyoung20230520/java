package ptj_5;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.GenericApplicationContext;

public class MainClass {
	public static void main(String[] args) {
		// 스프링 방식이 아니라 직접 객체를 생성해서 사용
//		TransfortationWalk tw = new TransfortationWalk();
//		tw.move();
		
		// IoC컨터에너에 생성되어 보관되고 있는 TransfortationWalk 객체를 받아서 사용
		ApplicationContext ctx =  
				new ClassPathXmlApplicationContext("applicationContext.xml");
		
		TransfortationWalk tw =  (TransfortationWalk) ctx.getBean("tWalk");
		tw.move();		
	}
}
