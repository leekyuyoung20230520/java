package ptj_5;

public class TransfortationWalk {

	public void move() {
		System.out.println("걸어서 이동합니다.");
	}
}
