package com.company.cookie.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MemberController {
	
	@GetMapping( { "", "/" , "/member" } )
	public String home() {
		System.out.println("[MemberController -- home ]");
		return "member/home";
	}
	
	@GetMapping("member/loginForm")
	public String loginForm() {
		System.out.println("[MemberController -- loginForm ]");
		return "member/login_form";
	}
	
	@PostMapping("member/loginConfirm")
	public String loginConfirm(@RequestParam("m_id") String m_id,
			@RequestParam("m_pw") String m_pw ,
			HttpServletResponse response
			) {
		System.out.println("[MemberController -- loginConfirm ]");
		
		String nextpage = "member/login_ng";
		// 임의로 user / 1234 면 로그인 성공
		if(m_id.equals("user") && m_pw.equals("1234")) {
			// 로그인 성공하면 쿠키에 정보를 저장
			Cookie cookie = new Cookie("loginMember", m_id);
			// 유효기간 셋팅
			cookie.setMaxAge(60*30);
			
			response.addCookie(cookie);
			
			nextpage = "member/login_ok";
		}	
		
		return nextpage;
	}
	
	@GetMapping("member/logoutForm")
	public String logoutForm( @CookieValue(value = "loginMember", required = false) String loginMember,
			HttpServletResponse response) {
		System.out.println("[MemberController -- logoutForm ]");
		// 클라이언트로부터 쿠키정보를 받아서 동일한 이름의 쿠키를 생성하고 
		// 쿠키의 휴효기간을 0로 설정해서 내려보낸다
		
		Cookie cookie = new Cookie("loginMember", loginMember);
		cookie.setMaxAge(0);
		
		response.addCookie(cookie);		
		
		// 리 다이렉트  클라이언트에게 서버로 해당 주소로 다시 요청 
		return "redirect:/member/";
	}

}
