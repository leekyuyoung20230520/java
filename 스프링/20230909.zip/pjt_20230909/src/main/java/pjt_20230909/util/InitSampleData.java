package pjt_20230909.util;
// 셈플 데이터 초기화
public class InitSampleData {

	private String[] names;
	private String[] phoneNumbers;
	public String[] getNames() {
		return names;
	}
	public void setNames(String[] names) {
		this.names = names;
	}
	public String[] getPhoneNumbers() {
		return phoneNumbers;
	}
	public void setPhoneNumbers(String[] phoneNumbers) {
		this.phoneNumbers = phoneNumbers;
	}
	
}
