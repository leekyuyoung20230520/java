package pjt_20230909.service;
import javax.annotation.Resource;

import pjt_20230909.dao.ContackDao;
import pjt_20230909.dao.ContackSet;

public class ContactRegisterService {
//	@Autowired
	@Resource
	private ContackDao contackDao;

//	// 기본생성자
//	public ContactRegisterService() {
//		System.out.println("기본생성자");
//	}
//	
//	// 생성자를 통한 객체 주입	
//	public ContactRegisterService(ContackDao contackDao) {
//		super();
//		System.out.println("contackDao : " + contackDao);
//		this.contackDao = contackDao;
//	}	
	
	// setter를 통한 객체 주입
	public void setContackDao(ContackDao contackDao) {
		this.contackDao = contackDao;
	}
	
	public void register(ContackSet contackSet) {
		if(verify(contackSet.getName())) {
			contackDao.insert(contackSet);
		}
		else {
			System.out.println("The name has already registered");
		}
	}
	
	// 기존 데이터베이스에 등록하려는 이름이 있는지 검사한다.
	public boolean verify(String name) {
		ContackSet contackSet = contackDao.select(name);
		return contackSet == null;
	}
	
	
}
