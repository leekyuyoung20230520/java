package pjt_20230909.service;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;

import pjt_20230909.dao.ContackDao;
import pjt_20230909.dao.ContackSet;

// 연락처 조회
public class ContactSearchService {
//	@Autowired
	@Resource
	private ContackDao contackDao;
//
//	//기본생성자
//	public ContactSearchService() {
//		System.out.println("default constructor");
//	}	
//	
//	public ContactSearchService(ContackDao contackDao) {
//		super();
//		System.out.println("ContackDao : " + contackDao);
//		this.contackDao = contackDao;
//	}

//	@Autowired
	public void setContackDao(ContackDao contackDao) {
		this.contackDao = contackDao;
	}
	
	public ContackSet searchContact(String name) {
		if(verify(name)) {
			return contackDao.select(name);
		}else {
			System.out.println("Contack information is avalilable");
		}
		return null;
	}
	// 기존 데이터베이스에 등록하려는 이름이 있는지 검사한다.
	public boolean verify(String name) {
		ContackSet contackSet = contackDao.select(name);
		return contackSet != null;
	}
}
