package spring5.BookRentalPjt.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring5.BookRentalPjt.library.book.BookVo;

@Service
public class UserBookService {
	@Autowired
	UserBookDao ubDao;

	public List<BookVo> searchBookConfirm(BookVo vo) {
		return ubDao.searchBookConfirm(vo);
	}

	public BookVo bookDetail(int b_no) {
		return ubDao.bookDetail(b_no);
	}

	public int rentalBookConfirm(int b_no, int u_m_no) {
		int result = ubDao.rentalBookConfirm(b_no,u_m_no);
		if(result>=0)
			ubDao.updateRentalBookAble(b_no);
		return result;
	}

	public List<RentalBookMergeVo> enterBookshelf(int u_m_no) {		
		return ubDao.enterBookshelf(u_m_no);
	}

}
