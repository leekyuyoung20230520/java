package spring5.BookRentalPjt.library.book;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import spring5.BookRentalPjt.user.RentalBookMergeVo;
import spring5.BookRentalPjt.user.RentalBookVo;

@Controller
@RequestMapping("/book/admin")
public class BookController {

	@Autowired
	BookService service;
	
	@Autowired
	UploadFileService fileService;
	
	// 도서 등록  화면 호출
	@GetMapping("/registerBookForm")
	public String registerBookForm() {
		System.out.println("[BookController] ---- registerBookForm");
		return "admin/book/register_book_form";
	}

	// 도서등록 화면에서 등록을위한 요청
	@PostMapping("/registerBookConfirm")
	public String registerBookForm(BookVo vo, @RequestParam("file") MultipartFile file) {
		System.out.println("[BookController post] ---- registerBookForm");
		String nextPage = "admin/book/register_book_ok";
		// 파일 저장
		String savedFileName =  fileService.upload(file);  // 실제로 파일을 저장
		if(savedFileName != null) {
			vo.setB_thumbnail(savedFileName);
			int result =  service.registerBookConfirm(vo); // 파일정보를 DB에 저장
			if (result <=0)
				nextPage = "admin/book/register_book_ng";
		}else
			nextPage = "admin/book/register_book_ng";
		
		return nextPage;
	}
	
	// 검색
	@GetMapping("/searchBookConfirm")
	public String searchBookConfirm(BookVo vo, Model model) {
		System.out.println("[BookController post] ---- searchBookConfirm");
		List<BookVo> bookVos =  service.searchBookConfirm(vo);
		model.addAttribute("bookVos", bookVos);
		return "admin/book/search_book"; 
	}
	// 상세화면
	@GetMapping("/bookDetail")
	public String bookDetail(@RequestParam("b_no") int b_no, Model model)	
	{
		System.out.println("[BookController post] ---- bookDetail");
		
		BookVo bookVo =  service.bookDetail(b_no);		
		model.addAttribute("bookVo", bookVo);
		return "admin/book/book_detail";
		
	}
	// 도서 수정 화면호출
	@GetMapping("/modifyBookForm")
	public String modifyBookForm(@RequestParam("b_no") int b_no, Model model) {
		System.out.println("[BookController post] ---- modifyBookForm");
		
		// b_no로 데이터를 DB로부터 조회해서 화면에 전달한다. -- detail과 기능이 같음
		BookVo bookVo =  service.bookDetail(b_no);		
		model.addAttribute("bookVo", bookVo);
		
		return "admin/book/modify_book_form";
	}
	// 도서 수정 process
	@PostMapping("modifyBookConfirm")
	public String modifyBookConfirm(BookVo vo, @RequestParam("file") MultipartFile file) 
	{
		System.out.println("[BookController post] ---- modifyBookConfirm");
		String nextPage = "admin/book/modify_book_ok";
		if(!file.getOriginalFilename().equals("")) {
			// 파일 저장
			String savedFileName =  fileService.upload(file);  // 실제로 파일을 저장
			if(savedFileName != null) {
				vo.setB_thumbnail(savedFileName);
			}				
		}
		
		int result =  service.modifyBookConfirm(vo); // 파일정보를 DB에 저장
		if (result <=0)
			nextPage = "admin/book/modify_book_ng";
		else
			nextPage = "admin/book/modify_book_ok";
		
		return nextPage;
	}
	@GetMapping("/deleteBookConfirm")
	public String deleteBookConfirm(@RequestParam("b_no") int b_no) {
		String nextPage = "admin/book/delete_book_ok";
		int result =  service.deleteBookConfirm(b_no);
		if(result < 0)
			nextPage = "admin/book/delete_book_ng";
		return nextPage;
	}
	
	// 관리자에서 로그인한후 대출도서 클릭
	@GetMapping("getRentalBooks")
	public String getRentalBooks(Model model) {
		List<RentalBookMergeVo> rentalBookMergeVo =  service.getRentalBooks();
		System.out.println("rentalBookMergeVo : " + rentalBookMergeVo);
		model.addAttribute("rentalBookVos",rentalBookMergeVo);
		return "admin/book/rental_books";
	}
}












