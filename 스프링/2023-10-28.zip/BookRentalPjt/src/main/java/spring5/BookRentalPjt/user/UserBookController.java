package spring5.BookRentalPjt.user;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import spring5.BookRentalPjt.library.book.BookVo;
import spring5.BookRentalPjt.user.member.UserMemberVo;

@Controller
@RequestMapping("/book/user")
public class UserBookController {
	@Autowired
	UserBookService ubservice;
	
	@GetMapping("/searchBookConfirm")
	public String searchBookConfirm(BookVo vo, Model model) {
		List<BookVo> bookLists = ubservice.searchBookConfirm(vo);
		model.addAttribute("bookVos",bookLists);
		return "user/book/search_book";
	}
	@GetMapping("/bookDetail")
	public String bookDetail(@RequestParam("b_no") int b_no, Model model) {
		BookVo bookVo =  ubservice.bookDetail(b_no);
		model.addAttribute("bookVo",bookVo);
		return "user/book/book_detail";
	}

	@GetMapping("/rentalBookConfirm")
	public String rentalBookConfirm(@RequestParam("b_no") int b_no, HttpSession session) {
		UserMemberVo loginedUserMemberVo = (UserMemberVo)session.getAttribute("loginedUserMemberVo");
//		if(loginedUserMemberVo == null)
//			return "redirect:/user/member/loginForm";
		
		// 랜탈정보를 등록
		int result = ubservice.rentalBookConfirm(b_no,loginedUserMemberVo.getU_m_no());
		if(result<=0)
			return "user/book/rental_book_ng";
		else
			return "user/book/rental_book_ok";
	}
	
//	나의 책장
	@GetMapping("/enterBookshelf")
	public String enterBookshelf(HttpSession session, Model model) {
		String nextPage = "user/book/bookshelf";
		UserMemberVo vo =  (UserMemberVo) session.getAttribute("loginedUserMemberVo");
		List<RentalBookMergeVo> books =  ubservice.enterBookshelf(vo.getU_m_no());
		model.addAttribute("rentalBookVos", books);
		
		return nextPage;
	}
	
}
