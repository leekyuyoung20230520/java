package spring5.BookRentalPjt.user.member;

// getter / setter를 대신하는 롬북을 상용  어노테이션을 통해 사용 , 코드를 간결하게 유지
// 

// 주로 테이블단위로 생성 vo객체 하나가 table에 row하나에 대응
public class UserMemberVo {
	private int u_m_no;		// 사용자 번호	
	private String u_m_id;	// 사용자 아이디
	private String u_m_pw;	// 사용자 비밀번호	
	private String u_m_name;	// 사용자 이름
	private String u_m_gender;	// 사용자 성별	
	private String u_m_mail;	// 사용자 메일
	private String u_m_phone;	// 사용자 연락처
	private String u_m_reg_date;	// 사용자 등록일
	private String u_m_mod_date;	// 사용자 수정일
	public int getU_m_no() {
		return u_m_no;
	}
	public void setU_m_no(int u_m_no) {
		this.u_m_no = u_m_no;
	}
	public String getU_m_id() {
		return u_m_id;
	}
	public void setU_m_id(String u_m_id) {
		this.u_m_id = u_m_id;
	}
	public String getU_m_pw() {
		return u_m_pw;
	}
	public void setU_m_pw(String u_m_pw) {
		this.u_m_pw = u_m_pw;
	}
	public String getU_m_name() {
		return u_m_name;
	}
	public void setU_m_name(String u_m_name) {
		this.u_m_name = u_m_name;
	}
	public String getU_m_gender() {
		return u_m_gender;
	}
	public void setU_m_gender(String u_m_gender) {
		this.u_m_gender = u_m_gender;
	}
	public String getU_m_mail() {
		return u_m_mail;
	}
	public void setU_m_mail(String u_m_mail) {
		this.u_m_mail = u_m_mail;
	}
	public String getU_m_phone() {
		return u_m_phone;
	}
	public void setU_m_phone(String u_m_phone) {
		this.u_m_phone = u_m_phone;
	}
	public String getU_m_reg_date() {
		return u_m_reg_date;
	}
	public void setU_m_reg_date(String u_m_reg_date) {
		this.u_m_reg_date = u_m_reg_date;
	}
	public String getU_m_mod_date() {
		return u_m_mod_date;
	}
	public void setU_m_mod_date(String u_m_mod_date) {
		this.u_m_mod_date = u_m_mod_date;
	}
	@Override
	public String toString() {
		return "UserMemberVo [u_m_no=" + u_m_no + ", u_m_id=" + u_m_id + ", u_m_pw=" + u_m_pw + ", u_m_name=" + u_m_name
				+ ", u_m_gender=" + u_m_gender + ", u_m_mail=" + u_m_mail + ", u_m_phone=" + u_m_phone
				+ ", u_m_reg_date=" + u_m_reg_date + ", u_m_mod_date=" + u_m_mod_date + "]";
	}
	
	
	
}
