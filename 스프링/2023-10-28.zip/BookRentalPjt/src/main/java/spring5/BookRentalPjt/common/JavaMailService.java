package spring5.BookRentalPjt.common;

import java.security.SecureRandom;
import java.util.Date;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;

// JavaMailService를 빈으로 등록
@Component
public class JavaMailService {

	@Autowired
	JavaMailSenderImpl javaMailSenderImpl;
	// 메일을 전송할 메세지 를 생성
	public void sendNewPasswordByMail(String toMailAddr, String newPassword) {
		final MimeMessagePreparator mimeMessagePreparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				final MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, true, "UTF-8");
				mimeMessageHelper.setTo(toMailAddr);
				mimeMessageHelper.setSubject("[반송불가] 새 비밀번호 안내입니다.");
				mimeMessageHelper.setText("새 비밀번호는 :" + newPassword, true);

			}
		};
		javaMailSenderImpl.send(mimeMessagePreparator);
	}

	// 난수를 이용해서 비밀번호를 생성
	public String createNewPassword() {
		char[] chars = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g',
				'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 'd', 't', 'u', 'v', 'w', 'x', 'y', 'z' };
		StringBuffer stringBuffer = new StringBuffer();
		SecureRandom secureRandom = new SecureRandom();
		secureRandom.setSeed(new Date().getTime());
		int index = 0;
		int length = chars.length;

		for (int i = 0; i < 8; i++) {
			index = secureRandom.nextInt(length);
			if (index % 2 == 0)
				stringBuffer.append(String.valueOf(chars[index]).toUpperCase());
			else
				stringBuffer.append(String.valueOf(chars[index]).toLowerCase());
		}
		System.out.println(stringBuffer.toString());
		return stringBuffer.toString();
	}
}
