package spring5.BookRentalPjt.library.book;

import java.io.File;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class UploadFileService {

	// 파일을 실제로 지정한 경로에 업로드..
	public String upload(MultipartFile file) {
		String fileOriName =  file.getOriginalFilename();
		String fileExtension = fileOriName.substring(fileOriName.lastIndexOf("."),
				fileOriName.length());
		String uploadDir = "c:/library/upload/";
		UUID uuid = UUID.randomUUID();  // 354a26b0-4cb7-40b4-88de-c1c795726147
		String uniqueName = uuid.toString().replaceAll("-", ""); // - 제거
		File saveFile = new File(uploadDir +uniqueName+ fileExtension);
		// c:/library/upload/354a26b04cb740b488dec1c795726147.jpg
		// 저장하려는 경로가 없으면 생성해 준다.
		if(!saveFile.exists())
			saveFile.mkdirs();
		
		try {
			file.transferTo(saveFile);
			System.out.println("uploade success");
			return uniqueName+ fileExtension;
		} catch (Exception e) {			
			e.printStackTrace();
		}		
		return null;
	}

}
