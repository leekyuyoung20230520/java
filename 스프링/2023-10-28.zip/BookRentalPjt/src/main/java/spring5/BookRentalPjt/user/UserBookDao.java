package spring5.BookRentalPjt.user;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import spring5.BookRentalPjt.library.book.BookVo;

@Repository
public class UserBookDao {
	@Autowired
	JdbcTemplate jdbct;
	
	public List<BookVo> searchBookConfirm(BookVo vo) {
		String sql = "select * from tbl_book where b_name like ?";
		List<BookVo> bookVo = null;
		try {
			bookVo = jdbct.query(sql, 
			(ResultSet rs, int rowNum)->{
				BookVo tempVo = new BookVo(
						rs.getInt("b_no"), rs.getString( "b_thumbnail"), 
						rs.getString("b_name"), rs.getString("b_author"), 
						rs.getString("b_publisher"),rs.getString("b_publish_year"), 
						rs.getString("b_isbn"), rs.getString("b_call_number"), 
						rs.getInt("b_rantal_able"), rs.getString("b_reg_date"),
						rs.getString("b_mod_date")
						);				
				return tempVo;
			},"%" + vo.getB_name() + "%" );
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bookVo.size() > 0 ? bookVo : null;		
	}

	public BookVo bookDetail(int b_no) {
		
		String sql = "select * from tbl_book where b_no = ?";
		List<BookVo> bookVo = null;
		try {
			bookVo = jdbct.query(sql, 
			(ResultSet rs, int rowNum)->{
				BookVo tempVo = new BookVo(
						rs.getInt("b_no"), rs.getString( "b_thumbnail"), 
						rs.getString("b_name"), rs.getString("b_author"), 
						rs.getString("b_publisher"),rs.getString("b_publish_year"), 
						rs.getString("b_isbn"), rs.getString("b_call_number"), 
						rs.getInt("b_rantal_able"), rs.getString("b_reg_date"),
						rs.getString("b_mod_date")
						);				
				return tempVo;
			},b_no);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bookVo.size() > 0 ? bookVo.get(0) : null;
	}

	public int rentalBookConfirm(int b_no, int u_m_no) {
		String sql = "INSERT INTO "
						+ "tbl_rental_book ( "
							+ "b_no, u_m_no, rb_start_date, rb_reg_date, rb_mod_date"
						+ ")	"
					+ "VALUES(	?,	?,	now(),now(),now())";
		
		return jdbct.update(sql,b_no,u_m_no);
	}

	public void updateRentalBookAble(int b_no) {
		String sql = "update tbl_book set b_rantal_able = 0 where b_no = ?";
		jdbct.update(sql,b_no);		
	}

	public List<RentalBookMergeVo> enterBookshelf(int u_m_no) {
		String sql = "select  "
				+ " tr.rb_no,  tr.b_no,  tr.u_m_no,  rb_start_date,  rb_end_date,										\r\n"
				+ " rb_reg_date,  rb_mod_date,  b_thumbnail,  b_name,  b_author,										\r\n"
				+ " b_publisher,  b_publish_year,  b_isbn,  b_call_number,  b_rantal_able,										\r\n"
				+ " b_reg_date,  b_mod_date,  u_m_id,  u_m_pw,  u_m_name,  u_m_gender,										\r\n"
				+ " u_m_mail,  u_m_phone,  u_m_reg_date,  u_m_mod_date"
				+ " from tbl_rental_book tr "
				+ "	join tbl_book tb on tr.b_no = tb.b_no "
				+ "    join tbl_user_member tm on tr.u_m_no = tm.u_m_no "
				+ "    where tr.u_m_no = ? and tr.rb_end_date is null";
		List<RentalBookMergeVo> volists =  jdbct.query(sql,
				
				(ResultSet rs, int rowNum) -> {
					RentalBookMergeVo tempVo = new RentalBookMergeVo(							  
							rs.getInt("rb_no"),
							rs.getInt("b_no"),
							rs.getInt("u_m_no"),
							rs.getString("rb_start_date"),	rs.getString("rb_end_date"),	
							rs.getString("rb_reg_date"),	rs.getString("rb_mod_date"),	
							rs.getString("b_thumbnail"),	rs.getString("b_name"),	
							rs.getString("b_author"),	rs.getString("b_publisher"),	
							rs.getString("b_publish_year"),	rs.getString("b_isbn"),	
							rs.getString("b_call_number"),	rs.getString("b_rantal_able"),	
							rs.getString("b_reg_date"),	rs.getString("b_mod_date"),	
							rs.getString("u_m_id"),	rs.getString("u_m_pw"),	
							rs.getString("u_m_name"),	rs.getString("u_m_gender"),	
							rs.getString("u_m_mail"),	rs.getString("u_m_phone"),	
							rs.getString("u_m_reg_date"),	rs.getString("u_m_mod_date")
							);	
					return tempVo;
				}
		, u_m_no);
		
		return volists;
	}

}
