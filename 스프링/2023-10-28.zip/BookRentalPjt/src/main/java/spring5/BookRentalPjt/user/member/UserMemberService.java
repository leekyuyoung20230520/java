package spring5.BookRentalPjt.user.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring5.BookRentalPjt.admin.member.AdminMemberService;
import spring5.BookRentalPjt.admin.member.AdminMemberVo;
import spring5.BookRentalPjt.common.JavaMailService;

@Service
public class UserMemberService {
	final static public int USER_ACCOUNT_ALREADY_EXIST = 0;
	final static public int USER_ACCOUNT_CREATE_SUCCESS = 1;
	final static public int USER_ACCOUNT_CREATE_FAIL = -1;

	@Autowired
	UserMemberDao umd;
	
	@Autowired
	JavaMailService javaMailService;
	
	public int createAccountForm(UserMemberVo userMemberVo) {
		// 데이터를 insert하기전에 생성하려는 유저가 있는지 확인
		boolean isMember  = umd.isUserMember(userMemberVo.getU_m_id());
		if(!isMember) {
			int result =  umd.createAccountForm(userMemberVo);
			if(result > 0)
				return USER_ACCOUNT_CREATE_SUCCESS;
			else
				return USER_ACCOUNT_CREATE_FAIL;
		}else {
			return USER_ACCOUNT_ALREADY_EXIST;
		}		
	}

	public UserMemberVo loginConfirm(UserMemberVo vo) {		
		return umd.loginConfirm(vo);
	}

	public int modifyAccountConfirm(UserMemberVo vo) {
		return umd.modifyAccountConfirm(vo);
	}

	public UserMemberVo getLoginedUserMemberVo(int u_m_no) {		
		return umd.getLoginedUserMemberVo(u_m_no);
	}

	public int findPasswordConfirm(UserMemberVo vo) {
		UserMemberVo userMemberVo =  umd.selectUser(vo.getU_m_id(),
				vo.getU_m_name(), vo.getU_m_mail()
				);
		int result = 0;
		if(userMemberVo != null) {
			//  임시패스워드 생성
			String newPassword =  javaMailService.createNewPassword();
			result = umd.updatePassowrd(userMemberVo.getU_m_id(), newPassword);
			if(result > 0)
				javaMailService.sendNewPasswordByMail(userMemberVo.getU_m_mail(),newPassword);
		}
		return result;
		
	}

}
