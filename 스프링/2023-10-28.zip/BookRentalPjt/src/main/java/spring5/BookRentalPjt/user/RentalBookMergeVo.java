package spring5.BookRentalPjt.user;

public class RentalBookMergeVo {
	int rb_no, b_no, u_m_no; 
	String rb_start_date, rb_end_date, rb_reg_date, rb_mod_date, b_thumbnail, b_name, b_author, b_publisher, b_publish_year, b_isbn, b_call_number, b_rantal_able, b_reg_date, b_mod_date, u_m_id, u_m_pw, u_m_name, u_m_gender, u_m_mail, u_m_phone, u_m_reg_date, u_m_mod_date;
	public int getRb_no() {
		return rb_no;
	}
	public void setRb_no(int rb_no) {
		this.rb_no = rb_no;
	}
	public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public int getU_m_no() {
		return u_m_no;
	}
	public void setU_m_no(int u_m_no) {
		this.u_m_no = u_m_no;
	}
	public String getRb_start_date() {
		return rb_start_date;
	}
	public void setRb_start_date(String rb_start_date) {
		this.rb_start_date = rb_start_date;
	}
	public String getRb_end_date() {
		return rb_end_date;
	}
	public void setRb_end_date(String rb_end_date) {
		this.rb_end_date = rb_end_date;
	}
	public String getRb_reg_date() {
		return rb_reg_date;
	}
	public void setRb_reg_date(String rb_reg_date) {
		this.rb_reg_date = rb_reg_date;
	}
	public String getRb_mod_date() {
		return rb_mod_date;
	}
	public void setRb_mod_date(String rb_mod_date) {
		this.rb_mod_date = rb_mod_date;
	}
	public String getB_thumbnail() {
		return b_thumbnail;
	}
	public void setB_thumbnail(String b_thumbnail) {
		this.b_thumbnail = b_thumbnail;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getB_author() {
		return b_author;
	}
	public void setB_author(String b_author) {
		this.b_author = b_author;
	}
	public String getB_publisher() {
		return b_publisher;
	}
	public void setB_publisher(String b_publisher) {
		this.b_publisher = b_publisher;
	}
	public String getB_publish_year() {
		return b_publish_year;
	}
	public void setB_publish_year(String b_publish_year) {
		this.b_publish_year = b_publish_year;
	}
	public String getB_isbn() {
		return b_isbn;
	}
	public void setB_isbn(String b_isbn) {
		this.b_isbn = b_isbn;
	}
	public String getB_call_number() {
		return b_call_number;
	}
	public void setB_call_number(String b_call_number) {
		this.b_call_number = b_call_number;
	}
	public String getB_rantal_able() {
		return b_rantal_able;
	}
	public void setB_rantal_able(String b_rantal_able) {
		this.b_rantal_able = b_rantal_able;
	}
	public String getB_reg_date() {
		return b_reg_date;
	}
	public void setB_reg_date(String b_reg_date) {
		this.b_reg_date = b_reg_date;
	}
	public String getB_mod_date() {
		return b_mod_date;
	}
	public void setB_mod_date(String b_mod_date) {
		this.b_mod_date = b_mod_date;
	}
	public String getU_m_id() {
		return u_m_id;
	}
	public void setU_m_id(String u_m_id) {
		this.u_m_id = u_m_id;
	}
	public String getU_m_pw() {
		return u_m_pw;
	}
	public void setU_m_pw(String u_m_pw) {
		this.u_m_pw = u_m_pw;
	}
	public String getU_m_name() {
		return u_m_name;
	}
	public void setU_m_name(String u_m_name) {
		this.u_m_name = u_m_name;
	}
	public String getU_m_gender() {
		return u_m_gender;
	}
	public void setU_m_gender(String u_m_gender) {
		this.u_m_gender = u_m_gender;
	}
	public String getU_m_mail() {
		return u_m_mail;
	}
	public void setU_m_mail(String u_m_mail) {
		this.u_m_mail = u_m_mail;
	}
	public String getU_m_phone() {
		return u_m_phone;
	}
	public void setU_m_phone(String u_m_phone) {
		this.u_m_phone = u_m_phone;
	}
	public String getU_m_reg_date() {
		return u_m_reg_date;
	}
	public void setU_m_reg_date(String u_m_reg_date) {
		this.u_m_reg_date = u_m_reg_date;
	}
	public String getU_m_mod_date() {
		return u_m_mod_date;
	}
	public void setU_m_mod_date(String u_m_mod_date) {
		this.u_m_mod_date = u_m_mod_date;
	}
	public RentalBookMergeVo(int rb_no, int b_no, int u_m_no, String rb_start_date, String rb_end_date,
			String rb_reg_date, String rb_mod_date, String b_thumbnail, String b_name, String b_author,
			String b_publisher, String b_publish_year, String b_isbn, String b_call_number, String b_rantal_able,
			String b_reg_date, String b_mod_date, String u_m_id, String u_m_pw, String u_m_name, String u_m_gender,
			String u_m_mail, String u_m_phone, String u_m_reg_date, String u_m_mod_date) {
		super();
		this.rb_no = rb_no;
		this.b_no = b_no;
		this.u_m_no = u_m_no;
		this.rb_start_date = rb_start_date;
		this.rb_end_date = rb_end_date;
		this.rb_reg_date = rb_reg_date;
		this.rb_mod_date = rb_mod_date;
		this.b_thumbnail = b_thumbnail;
		this.b_name = b_name;
		this.b_author = b_author;
		this.b_publisher = b_publisher;
		this.b_publish_year = b_publish_year;
		this.b_isbn = b_isbn;
		this.b_call_number = b_call_number;
		this.b_rantal_able = b_rantal_able;
		this.b_reg_date = b_reg_date;
		this.b_mod_date = b_mod_date;
		this.u_m_id = u_m_id;
		this.u_m_pw = u_m_pw;
		this.u_m_name = u_m_name;
		this.u_m_gender = u_m_gender;
		this.u_m_mail = u_m_mail;
		this.u_m_phone = u_m_phone;
		this.u_m_reg_date = u_m_reg_date;
		this.u_m_mod_date = u_m_mod_date;
	}
	@Override
	public String toString() {
		return "RentalBookMergeVo [rb_no=" + rb_no + ", b_no=" + b_no + ", u_m_no=" + u_m_no + ", rb_start_date="
				+ rb_start_date + ", rb_end_date=" + rb_end_date + ", rb_reg_date=" + rb_reg_date + ", rb_mod_date="
				+ rb_mod_date + ", b_thumbnail=" + b_thumbnail + ", b_name=" + b_name + ", b_author=" + b_author
				+ ", b_publisher=" + b_publisher + ", b_publish_year=" + b_publish_year + ", b_isbn=" + b_isbn
				+ ", b_call_number=" + b_call_number + ", b_rantal_able=" + b_rantal_able + ", b_reg_date=" + b_reg_date
				+ ", b_mod_date=" + b_mod_date + ", u_m_id=" + u_m_id + ", u_m_pw=" + u_m_pw + ", u_m_name=" + u_m_name
				+ ", u_m_gender=" + u_m_gender + ", u_m_mail=" + u_m_mail + ", u_m_phone=" + u_m_phone
				+ ", u_m_reg_date=" + u_m_reg_date + ", u_m_mod_date=" + u_m_mod_date + "]";
	}
	
	
}
