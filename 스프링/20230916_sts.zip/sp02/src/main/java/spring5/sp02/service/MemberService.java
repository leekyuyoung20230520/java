package spring5.sp02.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import spring5.sp02.dao.MemberDao;
import spring5.sp02.vo.MemberVO;

@Service
public class MemberService {

	@Autowired
	private MemberDao memberDao;
	
	public int signUpConfirm(MemberVO memberVo) {
		System.out.println("MemberService.signUpConfirm--------------");
		memberDao.insertMember(memberVo);
		return 0;
	}

	public boolean isSignInConfirm(MemberVO memberVo) {
		MemberVO vo =   memberDao.getMember(memberVo.getId());
		if(vo!=null & vo.getPsw().equals(memberVo.getPsw() ) )
			return true;
		else
			return false;
	}
	
	
}
