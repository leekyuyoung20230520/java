package spring5.sp02.vo;

public class MemberVO {

	private String id;
	private String psw;
	private String pswconfirm;
	private String phone;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPsw() {
		return psw;
	}
	public void setPsw(String psw) {
		this.psw = psw;
	}
	public String getPswconfirm() {
		return pswconfirm;
	}
	public void setPswconfirm(String pswconfirm) {
		this.pswconfirm = pswconfirm;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	@Override
	public String toString() {
		return "MemberVO [id=" + id + ", psw=" + psw + ", pswconfirm=" + pswconfirm + ", phone=" + phone + "]";
	}
	
	
}
