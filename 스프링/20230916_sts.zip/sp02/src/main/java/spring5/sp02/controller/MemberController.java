package spring5.sp02.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import spring5.sp02.service.MemberService;
import spring5.sp02.vo.MemberVO;

@Controller
public class MemberController {

	// 의존객체를 직접 주입
//	private MemberService memberService = new MemberService();
	@Autowired
	private MemberService memberService;
	

	// 화면 호출
	@GetMapping("/signup")
	public ModelAndView signup() {
		return new ModelAndView("member/signup");
	}
	
	// 해당화면에서 정보를 받아서 처리
	// 정보를 받을때는
	// @RequestParam
	// VO객체
	@PostMapping("/signup")
	public ModelAndView signupPost(MemberVO memberVo) {
//		System.out.println(memberVo);
		// 데이터를 서비스에 넘겨준다.		
		memberService.signUpConfirm(memberVo);
		
		return new ModelAndView("member/signup_ok");
	}
	
	
	//로그인 화면 호출
	@GetMapping("/login")
	public ModelAndView login() {		
		return new ModelAndView("/member/login");
	}
	// 로그인 처리
	@PostMapping("/login")
	public ModelAndView loginPost(MemberVO memberVo) {
		boolean isSuccess =  memberService.isSignInConfirm(memberVo);
		if(isSuccess)
			return new ModelAndView("/member/signin_ok"); // 로그인 성공시 이동할 페이지
		else
			return new ModelAndView("/member/signin_ng"); // 로그인 실패 이동할 페이지
	}
	
	// 아이디 중복 체크
	@PostMapping("/member/checkid")
	public void checkid(HttpServletRequest req, HttpServletResponse resp) throws IOException 
	{
		String id = req.getParameter("id");
		//
		resp.getWriter().write("available");
	}
}
