package spring5.sp02.dao;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

import spring5.sp02.vo.MemberVO;

@Component 
public class MemberDao {
	private Map<String, MemberVO> memberDB = new HashMap<>();
	
	public void insertMember(MemberVO memberVo) {
		System.out.println("MemberDao.insertMember----------");
		System.out.println(memberVo);
		// 데이터 insert
		memberDB.put(memberVo.getId(), memberVo);
		// all data 조회
		printAllMember();
	}
	
	public void printAllMember() {
		System.out.println("MemberDao.printAllMember--------------");
		for (Map.Entry<String, MemberVO> entry : memberDB.entrySet()) {
			String key = entry.getKey();
			MemberVO val = entry.getValue();
			System.out.println(key + ":" + val);			
			
		}
		
	}

	public MemberVO getMember(String id) {
		if(memberDB.containsKey(id)) {
			return memberDB.get(id);
		}
		else
			return null;
	}
}
