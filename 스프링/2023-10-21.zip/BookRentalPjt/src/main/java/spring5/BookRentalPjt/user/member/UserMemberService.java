package spring5.BookRentalPjt.user.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserMemberService {
	final static public int USER_ACCOUNT_ALREADY_EXIST = 0;
	final static public int USER_ACCOUNT_CREATE_SUCCESS = 1;
	final static public int USER_ACCOUNT_CREATE_FAIL = -1;

	@Autowired
	UserMemberDao umd;
	
	public int createAccountForm(UserMemberVo userMemberVo) {
		// 데이터를 insert하기전에 생성하려는 유저가 있는지 확인
		boolean isMember  = umd.isUserMember(userMemberVo.getU_m_id());
		if(!isMember) {
			int result =  umd.createAccountForm(userMemberVo);
			if(result > 0)
				return USER_ACCOUNT_CREATE_SUCCESS;
			else
				return USER_ACCOUNT_CREATE_FAIL;
		}else {
			return USER_ACCOUNT_ALREADY_EXIST;
		}		
	}

	public UserMemberVo loginConfirm(UserMemberVo vo) {		
		return umd.loginConfirm(vo);
	}

}
