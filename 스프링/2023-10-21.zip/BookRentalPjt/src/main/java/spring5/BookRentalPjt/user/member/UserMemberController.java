package spring5.BookRentalPjt.user.member;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user/member")
public class UserMemberController {

	@Autowired
	UserMemberService ums;
	
	@GetMapping("/createAccountForm")
	public String createAccountForm() {
		return "user/member/create_account_form";
	}
	
	@PostMapping("/createAccountConfirm")
	public String createAccountForm(UserMemberVo userMemberVo) {
		String nextPage = "user/member/create_account_ok";
		int result = ums.createAccountForm(userMemberVo);
		if(result <= 0)
			nextPage = "user/member/create_account_ng";
		
		return nextPage;
	}
	
	// 로그인 폼
	@GetMapping("/loginForm")
	public String loginForm() {
		return "user/member/login_form";
	}
	@PostMapping("/loginConfirm")
	public String loginConfirm(UserMemberVo vo, HttpSession session) {
		String nextPage = "user/member/login_ok";
		UserMemberVo loginedMemberVo = ums.loginConfirm(vo);
		if(loginedMemberVo != null) {
			session.setAttribute("loginedMemberVo", loginedMemberVo);
		}
		else {
			nextPage = "user/member/login_ng";
		}
		return nextPage;
	}
	
	
}
