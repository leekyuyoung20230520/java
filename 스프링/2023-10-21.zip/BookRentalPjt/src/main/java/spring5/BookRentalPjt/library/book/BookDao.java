package spring5.BookRentalPjt.library.book;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class BookDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public int insertBook(BookVo vo) {
		String sql = "    insert into tbl_book(b_thumbnail,"
				+ "                         b_name		,"
				+ "                         b_author	,"
				+ "                         b_publisher,"
				+ "                         b_publish_year,"
				+ "                         b_isbn			,"
				+ "                         b_call_number	,"
				+ "                         b_rantal_able	,"
				+ "                         b_reg_date 	,	"
				+ "                         b_mod_date		"
				+ "                         )"
				+ "                         values( ?,?,?,?,?,?,?,?,now(),now())";
		int result = -1;
		
		try {
			result = jdbcTemplate.update(sql,
					vo.getB_thumbnail(),vo.getB_name(),vo.getB_author(),
					vo.getB_publisher(),vo.getB_publish_year(),vo.getB_isbn(),
					vo.getB_call_number(),vo.getB_rantal_able()
					);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public List<BookVo> selectBookBySearch(BookVo vo) {
		String sql = "select * from tbl_book where b_name like ?";
		List<BookVo> bookVo = null;
		try {
			bookVo = jdbcTemplate.query(sql, 
			(ResultSet rs, int rowNum)->{
				BookVo tempVo = new BookVo(
						rs.getInt("b_no"), rs.getString( "b_thumbnail"), 
						rs.getString("b_name"), rs.getString("b_author"), 
						rs.getString("b_publisher"),rs.getString("b_publish_year"), 
						rs.getString("b_isbn"), rs.getString("b_call_number"), 
						rs.getInt("b_rantal_able"), rs.getString("b_reg_date"),
						rs.getString("b_mod_date")
						);				
				return tempVo;
			},"%" + vo.getB_name() + "%" );
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bookVo.size() > 0 ? bookVo : null;
	}

	public BookVo bookDetail(int b_no) {		
		String sql = "select * from tbl_book where b_no = ?";
		List<BookVo> bookVo = null;
		try {
			bookVo = jdbcTemplate.query(sql, 
			(ResultSet rs, int rowNum)->{
				BookVo tempVo = new BookVo(
						rs.getInt("b_no"), rs.getString( "b_thumbnail"), 
						rs.getString("b_name"), rs.getString("b_author"), 
						rs.getString("b_publisher"),rs.getString("b_publish_year"), 
						rs.getString("b_isbn"), rs.getString("b_call_number"), 
						rs.getInt("b_rantal_able"), rs.getString("b_reg_date"),
						rs.getString("b_mod_date")
						);				
				return tempVo;
			},b_no);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bookVo.size() > 0 ? bookVo.get(0) : null;
	}

	public int modifyBookConfirm(BookVo vo) {		
		List<String> args = new ArrayList<>();
		
		String sql = "update tbl_book set ";
		if(vo.getB_thumbnail() != null) {
			sql += "b_thumbnail=?, ";
			args.add(vo.getB_thumbnail());
		}
		sql += " b_name=?,";
		args.add(vo.getB_name());
		
		sql += "  b_author=?,";
		args.add(vo.getB_author());
		
		sql += "  b_publisher =?,";
		args.add(vo.getB_publisher());
		
		sql += " b_publish_year=?,";
		args.add(vo.getB_publish_year());
		
		sql += " b_isbn	=?,";
		args.add(vo.getB_isbn());
		
		sql += "  b_call_number=?	,";
		args.add(vo.getB_call_number());		
		
		sql += "  b_rantal_able	=?,";
		args.add( Integer.toString(vo.getB_rantal_able()));
		
		sql += "  b_mod_date	 = NOW()	";		
		
		sql += " where b_no = ?";
		args.add(Integer.toString(vo.getB_no()));
		
		int result = -1;
		
		try {
			result = jdbcTemplate.update(sql,args.toArray());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public int deleteBookConfirm(int b_no) {
		String sql = "delete from tbl_book where b_no=?";
		return jdbcTemplate.update(sql,b_no);
	}

}
