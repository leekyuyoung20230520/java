package spring5.BookRentalPjt.admin.member;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
@RequestMapping("/admin")
public class AdminMemberController {
	
	@Autowired
	private AdminMemberService adminService;

	@RequestMapping(value = {"","/"}, method = RequestMethod.GET)
	public String home() {
		System.out.println("AdminHomeController -- home");
		String nextPage = "admin/home";
		return nextPage;
	}
	
	// 관리자 회원가입 화면  - 처음에 화면을 보여준다..(양식을 보여준다)
	@RequestMapping(value = "/member/createAccountForm", method = RequestMethod.GET)
	public String createAccountForm() {
		System.out.println("AdminHomeController -- createAccountForm");
		String nextPage = "admin/member/create_account_form";
		return nextPage;
	}
	
	@PostMapping(value = "/member/createAccountConfirm")
	public String createAccountConfirm(AdminMemberVo vo) {
		System.out.println("AdminMemberController -- : \n" + vo + "\n----------");
		String nextPage = "admin/member/create_account_ok";
		int result =  adminService.createAccountConfirm(vo);
		if(result <=0) {
			nextPage = "admin/member/create_account_ng"; 
		}
		return nextPage;
	}
	
	// 로그인 폼 호출 - get방식
	@GetMapping("/member/loginForm")
	public String loginForm() {
		System.out.println("AdminMemberController--- loginForm");
		String nextPage = "admin/member/login_form";
		return nextPage;
	}
	// 로그인 처리
	@PostMapping("/member/loginConfirm")
	public String loginConfirm(AdminMemberVo vo, HttpSession session) {
		System.out.println("AdminMemberController---loginConfirm");
		String nextPage = "admin/member/login_ok";
		
		AdminMemberVo loginedAdminMemberVo =  adminService.loginConfirm(vo);
		if(loginedAdminMemberVo == null)
			nextPage = "admin/member/login_ng";
		else {
			session.setAttribute("loginedAdminMemberVo", loginedAdminMemberVo);
			session.setMaxInactiveInterval(60*30);
		}
		return nextPage;
	
	}
	// 로그아웃
	@GetMapping("/member/logoutConfirm")
	public String logoutConfirm(HttpSession session) {
		System.out.println("AdminMemberController---logoutConfirm");
		session.invalidate();   // 클라이언트에 대한 세션을 삭제
		
		return "redirect:/admin";
	}
	
	// 관리자 리스트 업
	@GetMapping("/member/listupAdmin")
	public String listupAdmin(Model model,HttpSession session) {   // 서버에서 클라으언트로 전달할 데이터를 담는 객체
		System.out.println("AdminMemberController---listupAdmin");
		
		AdminMemberVo loginedAdminMemberVo =  (AdminMemberVo) session.getAttribute("loginedAdminMemberVo");
		
		
		if (loginedAdminMemberVo != null 
				&& loginedAdminMemberVo.getA_m_id().equals("Super admin")) 
		{
			List<AdminMemberVo> adminMemberVos =  adminService.listupAdmin();		
			model.addAttribute("adminMemberVos",adminMemberVos);
		}
		
		
		return "admin/member/listup_admins";
	}
	
	// 일반관리자 승인하기 
//	member/setAdminApproval?a_m_no=1
	@GetMapping("/member/setAdminApproval")
	public String setAdminApproval(@RequestParam("a_m_no") String a_m_no) {
		System.out.println("AdminMemberController---setAdminApproval");
		
		adminService.selectAdminAmno(a_m_no);
		
		return "redirect:/admin/member/listupAdmin";
	}
	
	// 회원정보 수정을 위한 화면 호출
	@GetMapping("/member/modifyAccountForm")
	public String modifyAccessAccountForm(HttpSession session) {
		System.out.println("AdminMemberController---modifyAccessAccountForm");
		String nextPage = "admin/member/modify_account_form";
		// 세션정보를 통해서 로그인이 되어 있다고 하면
		AdminMemberVo loginedAdminMemberVo = 
				(AdminMemberVo)session.getAttribute("loginedAdminMemberVo");
		if (loginedAdminMemberVo == null)
			nextPage = "redirect:/admin/member/loginForm";
		return nextPage;
	}
	
	@PostMapping("/member/modifyAccountConfirm")
	public String modifyAccountConfirm(AdminMemberVo adminMemberVo, HttpSession session) {
		System.out.println("AdminMemberController---modifyAccountConfirm");
		String nextPage = "admin/member/modify_account_ok";
		// 제출된 정보를 가지고 db 수정작업을 진행
		int result =  adminService.modifyAccountConfirm(adminMemberVo);
		// 회원정보가 수정이 되면 기존 세션에 저장된 회원정보를 업데이트 한다.
		if(result > 0) {
			// 화면에서  read only 속성이 있기때문에 값을 못넘긴다. 그래서
			// DB 조회
			AdminMemberVo loginedAdminMemberVo  = adminService.getLoginedAdminMemberVo(adminMemberVo.getA_m_no());
			
			session.setAttribute("loginedAdminMemberVo", loginedAdminMemberVo);
		}else {
			nextPage = "admin/member/modify_account_ng";
		}
		return nextPage;
	}
	
	// 비밀번호 찾기 화면 호출
	@GetMapping("/member/findPasswordForm")
	public String findPasswordForm() {
		System.out.println("AdminMemberController---findPasswordForm");
		return "admin/member/find_password_form";
	}
	
	@PostMapping("/member/findPasswordConfirm")
	public String findPasswordForm(AdminMemberVo adminMemberVo) {
		System.out.println("AdminMemberController---findPasswordForm(AdminMemberVo adminMemberVo)");
		String nenxtPage = "admin/member/find_password_ok";
		
		int result = adminService.findPasswordConfirm(adminMemberVo);
		if (result <=0)
			nenxtPage = "admin/member/find_password_ng";
			
		return nenxtPage;
	}
			
}
