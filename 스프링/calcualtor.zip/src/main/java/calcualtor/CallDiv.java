package calcualtor;


public class CallDiv implements ICalculator {

	@Override
	public int doOperation(int i, int j) throws Exception {
		try {			
			return i / j;
		} catch (Exception e) {			
			throw new Exception(); 
		}
	}

}
