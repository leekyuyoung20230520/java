package calcualtor;


public class CallAdd implements ICalculator {

	@Override
	public int doOperation(int i, int j) {		
		return i + j;
	}

}
