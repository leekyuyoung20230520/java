package calcualtor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) throws Exception {
		ApplicationContext ctx = 
				new ClassPathXmlApplicationContext("classpath:applicationContext.xml");
		
		CallAssembler ca =  ctx.getBean("cAssembler", CallAssembler.class);
		ca.assemble();
	}

}
