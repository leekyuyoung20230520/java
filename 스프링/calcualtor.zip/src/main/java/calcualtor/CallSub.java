package calcualtor;


public class CallSub implements ICalculator {

	@Override
	public int doOperation(int i, int j) {		
		return i - j;
	}

}
