package spring5.BookRentalPjt.user;

public class RentalBookVo {
	private int rb_no;// 	-- 대출번호 pk
	private int b_no;//-- 도서정보
	private int u_m_no;//	-- 사용자 정보	
	private String rb_start_date;// default '1000-01-01',  			-- 대출일
	private String rb_end_date;//-- 반납일check
	private String rb_reg_date;// 			-- 등록일
	private String rb_mod_date;//      			-- 수정일
	public int getRb_no() {
		return rb_no;
	}
	public void setRb_no(int rb_no) {
		this.rb_no = rb_no;
	}
	public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public int getU_m_no() {
		return u_m_no;
	}
	public void setU_m_no(int u_m_no) {
		this.u_m_no = u_m_no;
	}
	public String getRb_start_date() {
		return rb_start_date;
	}
	public void setRb_start_date(String rb_start_date) {
		this.rb_start_date = rb_start_date;
	}
	public String getRb_end_date() {
		return rb_end_date;
	}
	public void setRb_end_date(String rb_end_date) {
		this.rb_end_date = rb_end_date;
	}
	public String getRb_reg_date() {
		return rb_reg_date;
	}
	public void setRb_reg_date(String rb_reg_date) {
		this.rb_reg_date = rb_reg_date;
	}
	public String getRb_mod_date() {
		return rb_mod_date;
	}
	public void setRb_mod_date(String rb_mod_date) {
		this.rb_mod_date = rb_mod_date;
	}
	@Override
	public String toString() {
		return "RentalBookVo [rb_no=" + rb_no + ", b_no=" + b_no + ", u_m_no=" + u_m_no + ", rb_start_date="
				+ rb_start_date + ", rb_end_date=" + rb_end_date + ", rb_reg_date=" + rb_reg_date + ", rb_mod_date="
				+ rb_mod_date + "]";
	}
	
}
