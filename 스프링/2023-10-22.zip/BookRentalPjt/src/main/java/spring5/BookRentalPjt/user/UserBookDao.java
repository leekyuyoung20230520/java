package spring5.BookRentalPjt.user;

import java.sql.ResultSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import spring5.BookRentalPjt.library.book.BookVo;

@Repository
public class UserBookDao {
	@Autowired
	JdbcTemplate jdbct;
	
	public List<BookVo> searchBookConfirm(BookVo vo) {
		String sql = "select * from tbl_book where b_name like ?";
		List<BookVo> bookVo = null;
		try {
			bookVo = jdbct.query(sql, 
			(ResultSet rs, int rowNum)->{
				BookVo tempVo = new BookVo(
						rs.getInt("b_no"), rs.getString( "b_thumbnail"), 
						rs.getString("b_name"), rs.getString("b_author"), 
						rs.getString("b_publisher"),rs.getString("b_publish_year"), 
						rs.getString("b_isbn"), rs.getString("b_call_number"), 
						rs.getInt("b_rantal_able"), rs.getString("b_reg_date"),
						rs.getString("b_mod_date")
						);				
				return tempVo;
			},"%" + vo.getB_name() + "%" );
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bookVo.size() > 0 ? bookVo : null;		
	}

	public BookVo bookDetail(int b_no) {
		
		String sql = "select * from tbl_book where b_no = ?";
		List<BookVo> bookVo = null;
		try {
			bookVo = jdbct.query(sql, 
			(ResultSet rs, int rowNum)->{
				BookVo tempVo = new BookVo(
						rs.getInt("b_no"), rs.getString( "b_thumbnail"), 
						rs.getString("b_name"), rs.getString("b_author"), 
						rs.getString("b_publisher"),rs.getString("b_publish_year"), 
						rs.getString("b_isbn"), rs.getString("b_call_number"), 
						rs.getInt("b_rantal_able"), rs.getString("b_reg_date"),
						rs.getString("b_mod_date")
						);				
				return tempVo;
			},b_no);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return bookVo.size() > 0 ? bookVo.get(0) : null;
	}

	public int rentalBookConfirm(int b_no, int u_m_no) {
		String sql = "INSERT INTO "
						+ "tbl_rental_book ( "
							+ "b_no, u_m_no, rb_start_date, rb_reg_date, rb_mod_date"
						+ ")	"
					+ "VALUES(	?,	?,	now(),now(),now())";
		
		return jdbct.update(sql,b_no,u_m_no);
	}

	public void updateRentalBookAble(int b_no) {
		String sql = "update tbl_book set b_rantal_able = 0 where b_no = ?";
		jdbct.update(sql,b_no);		
	}

}
