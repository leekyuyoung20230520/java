package spring5.BookRentalPjt.library.book;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {
	final static public int BOOK_ISBN_ALLREADY_EXIST = 0; //이미 등록된 도서
	final static public int BOOK_REGISTER_SUCCESS = 1; //이미 등록된 도서
	final static public int BOOK_REGISTER_FAIL = -1; //이미 등록된 도서
	
	
	@Autowired
	private BookDao bookDao;
	
	
	public int registerBookConfirm(BookVo vo) {		
		int result =  bookDao.insertBook(vo);
		if(result > 0)
			return  BOOK_REGISTER_SUCCESS;
		else
			return BOOK_REGISTER_FAIL;		
	}


	public List<BookVo> searchBookConfirm(BookVo vo) {		
		return bookDao.selectBookBySearch(vo);
	}


	public BookVo bookDetail(int b_no) {		
		return bookDao.bookDetail(b_no);
	}


	public int modifyBookConfirm(BookVo vo) {		
		return bookDao.modifyBookConfirm(vo);
	}


	public int deleteBookConfirm(int b_no) {		
		return bookDao.deleteBookConfirm(b_no);
	}

}
