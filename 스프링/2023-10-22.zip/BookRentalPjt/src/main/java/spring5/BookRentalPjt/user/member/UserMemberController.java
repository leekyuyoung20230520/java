package spring5.BookRentalPjt.user.member;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/user/member")
public class UserMemberController {

	@Autowired
	UserMemberService ums;
	
	@GetMapping("/createAccountForm")
	public String createAccountForm() {
		return "user/member/create_account_form";
	}
	
	@PostMapping("/createAccountConfirm")
	public String createAccountForm(UserMemberVo userMemberVo) {
		String nextPage = "user/member/create_account_ok";
		int result = ums.createAccountForm(userMemberVo);
		if(result <= 0)
			nextPage = "user/member/create_account_ng";
		
		return nextPage;
	}
	
	// 로그인 폼
	@GetMapping("/loginForm")
	public String loginForm() {
		return "user/member/login_form";
	}
	@PostMapping("/loginConfirm")
	public String loginConfirm(UserMemberVo vo, HttpSession session) {
		String nextPage = "user/member/login_ok";
		UserMemberVo loginedMemberVo = ums.loginConfirm(vo);
		if(loginedMemberVo != null) {			
			session.setAttribute("loginedUserMemberVo", loginedMemberVo);
		}
		else {
			nextPage = "user/member/login_ng";
		}
		return nextPage;
	}
	// 계정수정 화면
	@GetMapping("modifyAccountForm")
	public String modifyAccountForm(HttpSession session) {
		// 로그인이 되어 있을때 이동
		String nextPage = "user/member/modify_account_form";
		UserMemberVo  loginedUserMemberVo = (UserMemberVo)session.getAttribute("loginedUserMemberVo");
		if(loginedUserMemberVo == null)
			nextPage = "redirect:/user/member/loginForm";
		return nextPage;
	}
	// 사용자 계정수정 프로세스
	@PostMapping("modifyAccountConfirm")
	public String modifyAccountConfirm(UserMemberVo vo, HttpSession session) {
		String nextPage = "user/member/modify_account_ok";
		int result = ums.modifyAccountConfirm(vo);		
		if(result > 0) { // 업데이트 성공,DB에서 사용자 정보 조회 해서 세션에 새로 갱신
			UserMemberVo  loginedUserMemberVo 
				= ums.getLoginedUserMemberVo(vo.getU_m_no());
			session.setAttribute("loginedUserMemberVo", loginedUserMemberVo);			
		}
		else {
			nextPage = "user/member/modify_account_ng";
		}
		return nextPage;
	}
	//로그아웃
	@GetMapping("logoutConfirm")
	public String logoutConfirm(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}
	// 사용자 페스워드 찾기 화면
	@GetMapping("findPasswordForm")
	public String findPasswordForm() {
		return "user/member/find_password_form";
	}
	
	// 사용자 페스워드 찾기 로직
	@PostMapping("findPasswordConfirm")
	public String findPasswordConfirm(UserMemberVo vo) {
		String nextPage = "user/member/find_password_ok";
		int result = ums.findPasswordConfirm(vo);
		if(result <=0) {
			nextPage = "user/member/find_password_ng";
		}
		return nextPage;
	}
	
}









