package spring5.BookRentalPjt.user.member;

import java.sql.ResultSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Repository;

//@Component   // 단순히 빈을 등록하고 싶은 클래스
@Repository // 추천 주로 DAO성격에적용 예외처리를 편리하게 할수 있도록 지원 자동예외반환
public class UserMemberDao {

	@Autowired
	JdbcTemplate jdbct;

	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	public boolean isUserMember(String u_m_id) {
		String sql = "select count(*) from tbl_user_member where u_m_id=?";
		int result = jdbct.queryForObject(sql, Integer.class, u_m_id);
		return result > 0;
	}

	public int createAccountForm(UserMemberVo vo) {
		String sql = "insert into tbl_user_member( " + "u_m_id,u_m_pw,u_m_name,u_m_gender,"
				+ "u_m_mail,u_m_phone,u_m_reg_date,u_m_mod_date" + ") values(?,?,?,?,?,?,now(),now())";

		// 패스워드 암호화
		String encoder_pw = passwordEncoder.encode(vo.getU_m_pw());

		return jdbct.update(sql, vo.getU_m_id(), encoder_pw, vo.getU_m_name(), vo.getU_m_gender(), vo.getU_m_mail(),
				vo.getU_m_phone());
	}

	public UserMemberVo loginConfirm(UserMemberVo vo) {
		String sql = "select * from tbl_user_member where u_m_id=?";
		List<UserMemberVo> userMemberVos = jdbct.query(sql, (ResultSet rs, int rowNum) -> {
			UserMemberVo innerVo = new UserMemberVo();
			innerVo.setU_m_no(rs.getInt("u_m_no"));
			innerVo.setU_m_gender(rs.getString("u_m_gender"));
			innerVo.setU_m_id(rs.getString("u_m_id"));
			innerVo.setU_m_mail(rs.getString("u_m_mail"));
			innerVo.setU_m_mod_date(rs.getString("u_m_mod_date"));
			innerVo.setU_m_name(rs.getString("u_m_name"));
			innerVo.setU_m_phone(rs.getString("u_m_phone"));
			innerVo.setU_m_pw(rs.getString("u_m_pw"));
			innerVo.setU_m_reg_date(rs.getString("u_m_reg_date"));
			return innerVo;
		}, vo.getU_m_id());

		System.out.println("dao : " + userMemberVos);

		if (userMemberVos != null && !passwordEncoder.matches(vo.getU_m_pw(), userMemberVos.get(0).getU_m_pw())) {
			return null;
		}
		return userMemberVos.get(0);
	}

	public int modifyAccountConfirm(UserMemberVo vo) {
		String sql = "update tbl_user_member set " + "u_m_name=?, u_m_gender=?, u_m_mail=?,"
				+ "u_m_phone=?,u_m_mod_date=now() " + "where u_m_no=?";
		int result = jdbct.update(sql, vo.getU_m_name(), vo.getU_m_gender(), vo.getU_m_mail(), vo.getU_m_phone(),
				vo.getU_m_no());
		return result;
	}

	public UserMemberVo getLoginedUserMemberVo(int u_m_no) {
		String sql = "select * from tbl_user_member where u_m_no=?";
		List<UserMemberVo> userMemberVos = jdbct.query(sql, (ResultSet rs, int rowNum) -> {
			UserMemberVo innerVo = new UserMemberVo();
			innerVo.setU_m_no(rs.getInt("u_m_no"));
			innerVo.setU_m_gender(rs.getString("u_m_gender"));
			innerVo.setU_m_id(rs.getString("u_m_id"));
			innerVo.setU_m_mail(rs.getString("u_m_mail"));
			innerVo.setU_m_mod_date(rs.getString("u_m_mod_date"));
			innerVo.setU_m_name(rs.getString("u_m_name"));
			innerVo.setU_m_phone(rs.getString("u_m_phone"));
			innerVo.setU_m_pw(rs.getString("u_m_pw"));
			innerVo.setU_m_reg_date(rs.getString("u_m_reg_date"));
			return innerVo;
		}, u_m_no);

		return userMemberVos.get(0);
	}

	public UserMemberVo selectUser(String u_m_id, String u_m_name, String u_m_mail) {
		String sql = "select * from tbl_user_member " + "where u_m_id=? and u_m_name =? and u_m_mail=?";
		List<UserMemberVo> userMemberVos = jdbct.query(sql, (ResultSet rs, int rowNum) -> {
			UserMemberVo innerVo = new UserMemberVo();
			innerVo.setU_m_no(rs.getInt("u_m_no"));
			innerVo.setU_m_gender(rs.getString("u_m_gender"));
			innerVo.setU_m_id(rs.getString("u_m_id"));
			innerVo.setU_m_mail(rs.getString("u_m_mail"));
			innerVo.setU_m_mod_date(rs.getString("u_m_mod_date"));
			innerVo.setU_m_name(rs.getString("u_m_name"));
			innerVo.setU_m_phone(rs.getString("u_m_phone"));
			innerVo.setU_m_pw(rs.getString("u_m_pw"));
			innerVo.setU_m_reg_date(rs.getString("u_m_reg_date"));
			return innerVo;
		}, u_m_id, u_m_name, u_m_mail);

		return userMemberVos.get(0);
	}

	public int updatePassowrd(String u_m_id, String newPassword) {
		String sql = "update tbl_user_member set u_m_pw = ? where u_m_id=?";
		// 패스워드 암호화
		String encoder_pw = passwordEncoder.encode(newPassword);
		return jdbct.update(sql, encoder_pw, u_m_id);
	}

}
