package spring5.BookRentalPjt.admin.member;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

//@Component   // 단순히 빈을 등록하고 싶은 클래스
@Repository   // 추천  주로 DAO성격에적용 예외처리를 편리하게 할수 있도록 지원  자동예외반환
public class AdminMemberDao {
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private BCryptPasswordEncoder passwordEncoder;

	public boolean isAdminMember(String a_m_id) {
		String sql = "select count(*) from tbl_admin_member where a_m_id = ? ";
		int result =  jdbcTemplate.queryForObject(sql, Integer.class, a_m_id);		
		return result > 0;
	}

	public int insertAdminMemberAccount(AdminMemberVo vo) {
		List<String> args = new ArrayList<>();
		
		String sql = "INSERT INTO bookrental.tbl_admin_member(";
		String values = " VALUES(";
		if(vo.getA_m_id().equals("Super admin")) {
			sql += "a_m_approval, ";
			args.add("1");
			values+="?,";
		}
		sql += "a_m_id,a_m_pw,a_m_name,a_m_gender,a_m_part,a_m_position,a_m_mail,a_m_phone,a_m_reg_date,a_m_mod_date)";
		
		// 저장할 변수를 담을 리스트를 생성
		args.add(vo.getA_m_id()); 
		// 패스워드 암호화		
		args.add( passwordEncoder.encode(vo.getA_m_pw()) );
		
		args.add(vo.getA_m_name());
		args.add(vo.getA_m_gender()); args.add(vo.getA_m_part()); args.add(vo.getA_m_position());
		args.add(vo.getA_m_mail()); args.add(vo.getA_m_phone());		
		
		values += "?,?,?,?,?,?,?,?,NOW(),NOW())";
		
		int result = -1;
		try {
			result = jdbcTemplate.update(sql+values,args.toArray());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public AdminMemberVo selectAdmin(AdminMemberVo vo) {
		System.out.println("[AdminMemberDao]  selectAdmin");
		String sql = "select * from tbl_admin_member where a_m_id = ? and a_m_approval > 0";
		List<AdminMemberVo> adminMemberVos = new ArrayList<>();
		
		try {
//			adminMemberVos =  jdbcTemplate.query(sql, new RowMapper<AdminMemberVo>() {
//				@Override
//				public AdminMemberVo mapRow(ResultSet rs, int rowNum) throws SQLException {
//					AdminMemberVo adminMemberVo = new AdminMemberVo();
//					adminMemberVo.setA_m_no(rs.getInt("a_m_no"));
//					adminMemberVo.setA_m_approval(rs.getInt("a_m_approval"));
//					adminMemberVo.setA_m_id(rs.getString("a_m_id"));
//					adminMemberVo.setA_m_pw(rs.getString("a_m_pw"));
//					adminMemberVo.setA_m_name(rs.getString("a_m_name"));
//					adminMemberVo.setA_m_gender(rs.getString("a_m_gender"));
//					adminMemberVo.setA_m_part(rs.getString("a_m_part"));
//					adminMemberVo.setA_m_position(rs.getString("a_m_position"));
//					adminMemberVo.setA_m_mail(rs.getString("a_m_mail"));
//					adminMemberVo.setA_m_phone(rs.getString("a_m_phone"));
//					adminMemberVo.setA_m_reg_date(rs.getString("a_m_reg_date"));
//					adminMemberVo.setA_m_mod_date(rs.getString("a_m_mode_date"));					
//					return adminMemberVo;
//				}				
//			}, vo.getA_m_id());
			
			// 람다와 스트림 대처
			adminMemberVos = jdbcTemplate.query(sql, (rs, rowNum)->{
				AdminMemberVo adminMemberVo = new AdminMemberVo();
				adminMemberVo.setA_m_no(rs.getInt("a_m_no"));
				adminMemberVo.setA_m_approval(rs.getInt("a_m_approval"));
				adminMemberVo.setA_m_id(rs.getString("a_m_id"));
				adminMemberVo.setA_m_pw(rs.getString("a_m_pw"));
				adminMemberVo.setA_m_name(rs.getString("a_m_name"));
				adminMemberVo.setA_m_gender(rs.getString("a_m_gender"));
				adminMemberVo.setA_m_part(rs.getString("a_m_part"));
				adminMemberVo.setA_m_position(rs.getString("a_m_position"));
				adminMemberVo.setA_m_mail(rs.getString("a_m_mail"));
				adminMemberVo.setA_m_phone(rs.getString("a_m_phone"));
				adminMemberVo.setA_m_reg_date(rs.getString("a_m_reg_date"));
				adminMemberVo.setA_m_mod_date(rs.getString("a_m_mod_date"));					
				return adminMemberVo;
			}, vo.getA_m_id());
			
			if(adminMemberVos.size()>0  && !passwordEncoder.matches(vo.getA_m_pw(), adminMemberVos.get(0).a_m_pw))
				adminMemberVos.clear();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return adminMemberVos.size() >0? adminMemberVos.get(0) : null ;
	}

	public List<AdminMemberVo> selectAdmins() {
		String sql = "select * from tbl_admin_member where a_m_id <> 'Super admin'";
		List<AdminMemberVo> adminMemberVos = new ArrayList<>();
		
		try {
			
			adminMemberVos = jdbcTemplate.query(sql, (rs, rowNum)->{
				AdminMemberVo adminMemberVo = new AdminMemberVo();
				adminMemberVo.setA_m_no(rs.getInt("a_m_no"));
				adminMemberVo.setA_m_approval(rs.getInt("a_m_approval"));
				adminMemberVo.setA_m_id(rs.getString("a_m_id"));
				adminMemberVo.setA_m_pw(rs.getString("a_m_pw"));
				adminMemberVo.setA_m_name(rs.getString("a_m_name"));
				adminMemberVo.setA_m_gender(rs.getString("a_m_gender"));
				adminMemberVo.setA_m_part(rs.getString("a_m_part"));
				adminMemberVo.setA_m_position(rs.getString("a_m_position"));
				adminMemberVo.setA_m_mail(rs.getString("a_m_mail"));
				adminMemberVo.setA_m_phone(rs.getString("a_m_phone"));
				adminMemberVo.setA_m_reg_date(rs.getString("a_m_reg_date"));
				adminMemberVo.setA_m_mod_date(rs.getString("a_m_mod_date"));					
				return adminMemberVo;
			});
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return adminMemberVos;
	}

	public void selectAdminAmno(String a_m_no) {
		System.out.println("[AdminMemberDao]---selectAdminAmno");
		
		String sql = "update tbl_admin_member set a_m_approval = '1' where a_m_no = ?";
		int result = jdbcTemplate.update(sql, a_m_no);
		System.out.println("after update ");		
	}

}
