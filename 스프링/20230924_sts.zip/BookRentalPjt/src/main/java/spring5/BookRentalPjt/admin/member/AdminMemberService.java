package spring5.BookRentalPjt.admin.member;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminMemberService {
	final static public int ADMIN_ACCOUNT_ALREADY_EXIST = 0;
	final static public int ADMIN_ACCOUNT_CREATE_SUCCESS = 1;
	final static public int ADMIN_ACCOUNT_CREATE_FAIL = -1;
	
	
	@Autowired
	private AdminMemberDao adminDao;
	
	/**
	 * 1. 아이디 중복체크
	 * 2. dao를 통해 데이터베이스에 정보를 추가(insert)
	 * @param vo
	 * @return
	 */
	public int createAccountConfirm(AdminMemberVo vo) {
		System.out.println("AdminMemberService -- createAccountConfirm");
		
		boolean isMember =  adminDao.isAdminMember(vo.getA_m_id());
		if(isMember) {
			return ADMIN_ACCOUNT_ALREADY_EXIST;
		}else {
			int result = adminDao.insertAdminMemberAccount(vo);			
			return result > 0? ADMIN_ACCOUNT_CREATE_SUCCESS : ADMIN_ACCOUNT_CREATE_FAIL;
			
		}
	}

	public AdminMemberVo loginConfirm(AdminMemberVo vo) {
		AdminMemberVo loginedAdminMemberVo =  adminDao.selectAdmin(vo);
		if(loginedAdminMemberVo != null) {
			System.out.println("[AdminMemberService] ADMIN MEMBER LOGIN SUCCESS");			
		}
		else
			System.out.println("[AdminMemberService] ADMIN MEMBER LOGIN FAIL");
		return loginedAdminMemberVo;
	}

	public List<AdminMemberVo> listupAdmin() {
		System.out.println("[AdminMemberService --- listupAdmin]");
		
		return adminDao.selectAdmins();
	}

	public void selectAdminAmno(String a_m_no) {
		adminDao.selectAdminAmno(a_m_no);
		
	}
}
