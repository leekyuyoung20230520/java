package spring5.BookRentalPjt.user.member;

import org.springframework.stereotype.Service;

@Service
public class UserMemberService {

}
