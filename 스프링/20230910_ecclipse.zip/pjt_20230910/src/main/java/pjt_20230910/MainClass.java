package pjt_20230910;

import java.util.Arrays;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import pjt_20230910.configuration.InitDataConfig;
import pjt_20230910.configuration.MemberConfig;
import pjt_20230910.dao.ContackSet;
import pjt_20230910.service.ContactRegisterService;
import pjt_20230910.service.ContactSearchService;
import pjt_20230910.util.InitSampleData;

public class MainClass {	
	
	public static void main(String[] args) {		
		// Ioc 컨테이너  생성 -- oooooo.xml을 활성화
//		ApplicationContext ctx 
//		= new GenericXmlApplicationContext("classpath:appCtx.xml");
		
		ApplicationContext ctx 
				= new AnnotationConfigApplicationContext(MemberConfig.class,InitDataConfig.class);
		
		
		// 샘플 데이터
		InitSampleData initSampleData = ctx.getBean("initSampleData",InitSampleData.class);
		String[] names = initSampleData.getNames();
		String[] phoneNumbers = initSampleData.getPhoneNumbers();
				
		System.out.println( Arrays.toString(names) );
		System.out.println( Arrays.toString(phoneNumbers) );
		
		// 데이터 등록
		ContactRegisterService reg = ctx.getBean("contactRegisterService",ContactRegisterService.class);
		for (int i = 0; i < phoneNumbers.length; i++) {
			ContackSet data = new ContackSet(names[i], phoneNumbers[i]);
			reg.register(data);			
		}
		
		// 데이터 조회
		ContactSearchService search = ctx.getBean("contactSearchService",ContactSearchService.class);
		ContackSet data =  search.searchContact("이규영");
		System.out.println(data);
	}
}
