package pjt_20230910.dao;
// 데이터베이스(데이터) 접근
// hashmap, insert search 기능

import java.util.HashMap;
import java.util.Map;

public class ContackDao {
	
	private Map<String, ContackSet> contackDB = new HashMap<String, ContackSet>();
	public void insert(ContackSet contackSet) {
		contackDB.put(contackSet.getName(), contackSet);
	}
	
	public ContackSet select(String name) {
		return contackDB.get(name);
	}
	
	public Map<String, ContackSet> getContackDB(){
		return contackDB;
	}

}
