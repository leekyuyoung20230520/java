package pjt_20230910.dao;
// 연락처 1개 정보
public class ContackSet {
	private String name;
	private String phoneNumber;
	public ContackSet(String name, String phoneNumber) {
		super();
		this.name = name;
		this.phoneNumber = phoneNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	@Override
	public String toString() {
		return "ContackSet [name=" + name + ", phoneNumber=" + phoneNumber + "]";
	}
	
	
}
