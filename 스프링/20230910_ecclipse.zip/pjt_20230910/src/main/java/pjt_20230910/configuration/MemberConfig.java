package pjt_20230910.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import pjt_20230910.dao.ContackDao;
import pjt_20230910.service.ContactRegisterService;
import pjt_20230910.service.ContactSearchService;
import pjt_20230910.util.InitSampleData;

// applicationContext.xml을 java형태로
@Configuration
public class MemberConfig {
	@Bean
	public ContackDao contackDao() {
		return new ContackDao();
	}
	@Bean
	public ContactRegisterService contactRegisterService() {
		return new ContactRegisterService();
	}
	@Bean
	public ContactSearchService contactSearchService() {
		return new ContactSearchService();
	}
	
	
}
