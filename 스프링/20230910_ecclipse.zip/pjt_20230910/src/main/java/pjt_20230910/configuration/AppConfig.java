package pjt_20230910.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({InitDataConfig.class, 
	MemberConfig.class})
public class AppConfig {

}
