package pjt_20230910.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import pjt_20230910.util.InitSampleData;

@Configuration
public class InitDataConfig {

	@Bean
	public InitSampleData initSampleData() {
		InitSampleData data = new InitSampleData();
		String[] names = {"이규영","홍길동","임꺽정"};
		String[] phoneNumbers = {"010-000-0000",
				"010-111-1111",
				"010-222-2222"};
		data.setNames(names);
		data.setPhoneNumbers(phoneNumbers);
		return data;
	}
}
