package service;
// 전체 학생정보 조회

import java.util.Map;

import dao.StudentDao;
import member.StudentVO;

public class StudentAllSelectService {
	private StudentDao studentDao;

	public StudentAllSelectService(StudentDao studentDao) {
		super();
		this.studentDao = studentDao;
	}
	public Map<String, StudentVO> allSelect(){
		return studentDao.getStudentDB();
	}
}
