package service;
// 학생 한명의 정보를 얻는 기능

import dao.StudentDao;
import member.StudentVO;

public class StudentSelectService {
	private StudentDao studentDao;

	public StudentSelectService(StudentDao studentDao) {
		super();
		this.studentDao = studentDao;
	}
	
	public StudentVO select(String sNum) {
		if(!studentDao.verify(sNum))
			return studentDao.select(sNum);
		else {
			System.out.println("조회하려는 학생정보가 없습니다.");
			return null;
		}
			
	}
}
