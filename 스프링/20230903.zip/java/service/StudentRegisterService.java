package service;
// 학생 정보 등록

import dao.StudentDao;
import member.StudentVO;

public class StudentRegisterService {

	private StudentDao studentDao;

	public StudentRegisterService(StudentDao studentDao) {
		super();
		this.studentDao = studentDao;
	}
	
	
	public void register(StudentVO stduent) {
		if(studentDao.verify(stduent.getsNum()))
			studentDao.insert(stduent);
		else
			System.out.println("학생정보가 이미 존재합니다.");
	}
	
	
	
}
