package service;

import dao.StudentDao;

public class StudentDeleteService {

	private StudentDao studentDao;

	public StudentDeleteService(StudentDao studentDao) {
		super();
		this.studentDao = studentDao;
	}
	public void delete(String sNum) {
		if(!studentDao.verify(sNum))
			studentDao.delete(sNum);
		else
			System.out.println("학생정보가 없습니다.");
	}
}
