package service;

import java.util.Map;

import member.StudentVO;

// 학생정보 출력
public class PrintStudentInformationService {

	private StudentAllSelectService allService;

	public PrintStudentInformationService(StudentAllSelectService allService) {
		super();
		this.allService = allService;
	}
	
	public void printStudentsInfo() {
		Map<String, StudentVO> allStudent = allService.allSelect();		
		for (Map.Entry<String, StudentVO> entry : allStudent.entrySet()) {
//			String key = entry.getKey();
			StudentVO student = entry.getValue();
			System.out.println(student);			
		}
	}
}
