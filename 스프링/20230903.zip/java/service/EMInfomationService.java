package service;
// 시스템정보
// 개발연도, 개발자,버전등의 정보를 담고 있는 클래스
public class EMInfomationService {

}
