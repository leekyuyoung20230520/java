package service;

import dao.StudentDao;
import member.StudentVO;

public class StudentModifyService {

	private StudentDao studentDao;

	public StudentModifyService(StudentDao studentDao) {
		super();
		this.studentDao = studentDao;
	}
	
	public void modify(StudentVO vo) {
		if(!studentDao.verify(vo.getsNum()))
			studentDao.update(vo);
		else
			System.out.println("학생정보가 없습니다.");
	}
}
