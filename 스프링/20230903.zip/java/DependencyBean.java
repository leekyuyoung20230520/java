
public class DependencyBean {

	InjectionBean ib;

	public DependencyBean(InjectionBean ib) {
		super();
		this.ib = ib;
	}
	
}
