package util;
// 프로젝트 시작하면 기본 데이터 셋팅용도 - 데이터 초기화 5명
public class InitSampleData {

		private String[] sNums = {"230105","230106","230107","230108","230109"};
		private String[] sIds = {"abc","aa","bb","cc","dd"};
		private String[] sPws = {"11","22","33","44","55"};
		private String[] sNames = {"kim","hong","lee","choi","bark"};
		private int[] sAges = {25,29,35,40,50};
		private String[] sGenders = {"M","M","W","W","W"};
		private String[] sMajors = {"English","MathMathics","Krorean","History","Science"};
		
		public String[] getsNums() {
			return sNums;
		}
		public void setsNums(String[] sNums) {
			this.sNums = sNums;
		}
		public String[] getsIds() {
			return sIds;
		}
		public void setsIds(String[] sIds) {
			this.sIds = sIds;
		}
		public String[] getsPws() {
			return sPws;
		}
		public void setsPws(String[] sPws) {
			this.sPws = sPws;
		}
		public String[] getsNames() {
			return sNames;
		}
		public void setsNames(String[] sNames) {
			this.sNames = sNames;
		}
		public int[] getsAges() {
			return sAges;
		}
		public void setsAges(int[] sAges) {
			this.sAges = sAges;
		}
		public String[] getsGenders() {
			return sGenders;
		}
		public void setsGenders(String[] sGenders) {
			this.sGenders = sGenders;
		}
		public String[] getsMajors() {
			return sMajors;
		}
		public void setsMajors(String[] sMajors) {
			this.sMajors = sMajors;
		}
		
}
