
public class InjectionBean {

}
