import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import member.StudentVO;
import service.PrintStudentInformationService;
import service.StudentDeleteService;
import service.StudentModifyService;
import service.StudentRegisterService;
import service.StudentSelectService;
import util.InitSampleData;

public class MainClass {

//	public static void main(String[] args) {		
//		 
//		String[] appCtxs = {"applicationContext.xml","dbConfig.xml"}; 
//				
//		ApplicationContext ctx = 
//				new GenericXmlApplicationContext("classpath:applicationContext.xml");
////				new GenericXmlApplicationContext(appCtxs);		
//		
//		// 데이터 준비
//		InitSampleData initSampleData = ctx.getBean("initSampleData",InitSampleData.class);
//		String[] sNums =  initSampleData.getsNums();
//		String[] sIds = initSampleData.getsIds();
//		String[] sPws = initSampleData.getsPws();
//		String[] sNames = initSampleData.getsNames();
//		int[] sAges = initSampleData.getsAges();
//		String[] sGenders = initSampleData.getsGenders();
//		String[] sMajors = initSampleData.getsMajors();
//		
//		// 데이터베이스 샘플 데이터 등록
//		StudentRegisterService sr =  ctx.getBean("studentRegisterService", StudentRegisterService.class);
//		for (int i = 0; i < 5; i++) {
//			StudentVO vo = new StudentVO(sNums[i], sIds[i], sPws[i], 
//					sNames[i], sAges[i], sGenders[i], sMajors[i]);
//			sr.register(vo);			
//		}
//		// 학생리스트
//		PrintStudentInformationService psinfo 
//		=  ctx.getBean("printStudentInformationService",PrintStudentInformationService.class);
//		psinfo.printStudentsInfo();
//		
//		System.out.println("========================= 학생등록 ==================================");
//		StudentRegisterService srs =  ctx.getBean("studentRegisterService",StudentRegisterService.class);
//		srs.register(new StudentVO("0001", "abc", "123", "홍길동", 25, "W", "korean"));		
//		// 학생리스트로 등록되어있는지 확인
//		psinfo.printStudentsInfo();
//		
//		System.out.println("========================= 230105 학생수정 ==================================");
//		StudentModifyService sms =  ctx.getBean("studentModifyService", StudentModifyService.class);
//		// 기존에 있는 학생정보를 가져와서 필요한부분을 수정한후 modify에 적용
//		StudentSelectService sss =  ctx.getBean("studentSelectService",StudentSelectService.class);
//		StudentVO vo =  sss.select("230105");
//		vo.setsPw("1234567890");
//		
//		sms.modify(vo); // 수정
//		psinfo.printStudentsInfo(); // 출력
//		
//		System.out.println("========================= 230105 학생삭제 ==================================");
//		StudentDeleteService sds =  ctx.getBean("studentDeleteService", StudentDeleteService.class);
//		sds.delete("230105");
//		psinfo.printStudentsInfo(); // 출력
//
//	}

}
