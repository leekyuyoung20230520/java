import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import member.StudentVO;
import service.PrintStudentInformationService;
import service.StudentDeleteService;
import service.StudentModifyService;
import service.StudentRegisterService;
import service.StudentSelectService;
import util.InitSampleData;

public class MainClass2 {

	public static void main(String[] args) {		
		 
		ApplicationContext ctx 
		= new GenericXmlApplicationContext("classpath:applicationContext.xml");
		
		DependencyBean ddb1 =  ctx.getBean("dependency",DependencyBean.class);
		DependencyBean ddb2 =  ctx.getBean("dependency",DependencyBean.class);
		System.out.println(ddb1);
		System.out.println(ddb2);
	}

}
