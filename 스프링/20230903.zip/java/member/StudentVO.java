package member;
// DB테이블과 동일한 맴버를 가지고 있는 객체
public class StudentVO {

	private String sNum;
	private String sId;
	private String sPw;
	private String sName;
	private int sAge;
	private String sGender;
	private String sMajor;
	public StudentVO(String sNum, String sId, String sPw, String sName, int sAge, String sGender, String sMajor) {
		super();
		this.sNum = sNum;
		this.sId = sId;
		this.sPw = sPw;
		this.sName = sName;
		this.sAge = sAge;
		this.sGender = sGender;
		this.sMajor = sMajor;
	}
	public String getsNum() {
		return sNum;
	}
	public void setsNum(String sNum) {
		this.sNum = sNum;
	}
	public String getsId() {
		return sId;
	}
	public void setsId(String sId) {
		this.sId = sId;
	}
	public String getsPw() {
		return sPw;
	}
	public void setsPw(String sPw) {
		this.sPw = sPw;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public int getsAge() {
		return sAge;
	}
	public void setsAge(int sAge) {
		this.sAge = sAge;
	}
	public String getsGender() {
		return sGender;
	}
	public void setsGender(String sGender) {
		this.sGender = sGender;
	}
	public String getsMajor() {
		return sMajor;
	}
	public void setsMajor(String sMajor) {
		this.sMajor = sMajor;
	}
	@Override
	public String toString() {
		return "StudentVO [sNum=" + sNum + ", sId=" + sId + ", sPw=" + sPw + ", sName=" + sName + ", sAge=" + sAge
				+ ", sGender=" + sGender + ", sMajor=" + sMajor + "]";
	}	
}
