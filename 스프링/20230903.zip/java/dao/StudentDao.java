package dao;
// Student table에 접근 insert update delete search 기능 수행
// 1차  - DB 없이 map 구조로 정보를 접근하고사용

import java.util.HashMap;
import java.util.Map;

import member.StudentVO;
// key는 sNum : 학번
public class StudentDao {
	// DB 역활
	private Map<String, StudentVO> studentDB = new HashMap<String, StudentVO>();
	
	public void insert(StudentVO vo) {
		studentDB.put(vo.getsNum(), vo);
	}
	
	public StudentVO select(String sNum) {
		return studentDB.get(sNum);
	}
	
	public void update(StudentVO vo) {
		studentDB.put(vo.getsNum(), vo);
	}
	public void delete(String sNum) {
		studentDB.remove(sNum);
	}
	// 전체 학생정보를 반환
	public Map<String, StudentVO> getStudentDB() {
		return studentDB;
	}
	
	// 학생번호가 이미 데이터에 저장되어 있으면 True
	public boolean verify(String sNum) {
		return select(sNum) == null? true : false;
	}
	
	
}
