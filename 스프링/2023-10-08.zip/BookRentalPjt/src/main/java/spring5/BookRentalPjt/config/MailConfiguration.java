package spring5.BookRentalPjt.config;

import java.util.Properties;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;


@Configuration
@ComponentScan(basePackages="spring5.BookRentalPjt")
@EnableWebMvc
public class MailConfiguration extends WebMvcConfigurerAdapter {

	// 자바로 메일 서비스 할수 있는 객체를 생성해서 리턴
	// 비번 2단계 앱 비밀번호 ibek mfvf onkr dody
	@Bean
	public JavaMailSenderImpl javaMailSenderImpl() {
		JavaMailSenderImpl javaMail = new JavaMailSenderImpl();
		javaMail.setHost("smtp.gmail.com");
		javaMail.setPort(587);
		javaMail.setUsername("pia222.kr.1@gmail.com");  // 자신의 구글아이디
		javaMail.setPassword("ibek mfvf onkr dody");  // 자신의 구글 패스워드
		
		Properties p = new Properties();		
		p.put("mail_smtp_auth", true);
		p.put("mail.smtp.starttls.enable", true);		
				
		javaMail.setJavaMailProperties(p);
		javaMail.setDefaultEncoding("UTF-8");
		return javaMail;
	}
	
}
