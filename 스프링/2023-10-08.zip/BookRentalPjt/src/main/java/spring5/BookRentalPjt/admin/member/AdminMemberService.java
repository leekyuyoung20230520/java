package spring5.BookRentalPjt.admin.member;

import java.security.SecureRandom;
import java.util.Date;
import java.util.List;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;

@Service
public class AdminMemberService {
	final static public int ADMIN_ACCOUNT_ALREADY_EXIST = 0;
	final static public int ADMIN_ACCOUNT_CREATE_SUCCESS = 1;
	final static public int ADMIN_ACCOUNT_CREATE_FAIL = -1;
	
	
	@Autowired
	private AdminMemberDao adminDao;
	
	@Autowired
	private JavaMailSenderImpl javaMailSenderImpl;
	
	/**
	 * 1. 아이디 중복체크
	 * 2. dao를 통해 데이터베이스에 정보를 추가(insert)
	 * @param vo
	 * @return
	 */
	public int createAccountConfirm(AdminMemberVo vo) {
		System.out.println("AdminMemberService -- createAccountConfirm");
		
		boolean isMember =  adminDao.isAdminMember(vo.getA_m_id());
		if(isMember) {
			return ADMIN_ACCOUNT_ALREADY_EXIST;
		}else {
			int result = adminDao.insertAdminMemberAccount(vo);			
			return result > 0? ADMIN_ACCOUNT_CREATE_SUCCESS : ADMIN_ACCOUNT_CREATE_FAIL;
			
		}
	}

	public AdminMemberVo loginConfirm(AdminMemberVo vo) {
		AdminMemberVo loginedAdminMemberVo =  adminDao.selectAdmin(vo);
		if(loginedAdminMemberVo != null) {
			System.out.println("[AdminMemberService] ADMIN MEMBER LOGIN SUCCESS");			
		}
		else
			System.out.println("[AdminMemberService] ADMIN MEMBER LOGIN FAIL");
		return loginedAdminMemberVo;
	}

	public List<AdminMemberVo> listupAdmin() {
		System.out.println("[AdminMemberService --- listupAdmin]");
		
		return adminDao.selectAdmins();
	}

	public void selectAdminAmno(String a_m_no) {
		adminDao.selectAdminAmno(a_m_no);
		
	}

	// 관리자 정보를 업데이트
	public int modifyAccountConfirm(AdminMemberVo adminMemberVo) {	
		return adminDao.modifyAccountConfirm(adminMemberVo) ;
	}
	
	// 관리자 정보 가져오기
	public AdminMemberVo getLoginedAdminMemberVo(int a_m_no) {
		return adminDao.selectAdmin(a_m_no);
	}

	public int findPasswordConfirm(AdminMemberVo adminMemberVo) {
		AdminMemberVo vo =  adminDao.selectAdmin(adminMemberVo.getA_m_id(),
				adminMemberVo.getA_m_name(), adminMemberVo.getA_m_mail()
				);
		int result = 0;
		if(vo != null) {
			//  임시패스워드 생성
			String newPassword =  createNewPassword();
			result = adminDao.updatePassowrd(adminMemberVo.getA_m_id(), newPassword);
			if(result > 0)
				sendNewPasswordByMail(adminMemberVo.getA_m_mail(),newPassword);
		}
		return result;
	}

	// 메일을 전송할 메세지 를 생성
	private void sendNewPasswordByMail(String toMailAddr, String newPassword) {
		final MimeMessagePreparator mimeMessagePreparator = new MimeMessagePreparator() {
			
			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				final MimeMessageHelper mimeMessageHelper = 
						new MimeMessageHelper(mimeMessage,true,"UTF-8");
				mimeMessageHelper.setTo(toMailAddr);
				mimeMessageHelper.setSubject("[반송불가] 새 비밀번호 안내입니다.");
				mimeMessageHelper.setText("새 비밀번호는 :" +newPassword,true );
				
			}
		};
		javaMailSenderImpl.send(mimeMessagePreparator);
	}

	// 난수를 이용해서 비밀번호를 생성
	private String createNewPassword() {
		char[] chars = new char[] {
			'0','1','2','3','4','5','6','7','8','9',
			'a','b','c','d','e','f','g','h','i','j','k','l','m','n',
			'o','p','q','r','d','t','u','v','w','x','y','z'
		};
		StringBuffer stringBuffer = new StringBuffer();
		SecureRandom secureRandom = new SecureRandom();
		secureRandom.setSeed(new Date().getTime());
		int index = 0;
		int length = chars.length;
		
		for (int i = 0; i < 8; i++) {
			index = secureRandom.nextInt(length);
			if(index % 2 == 0)
				stringBuffer.append(String.valueOf(chars[index]).toUpperCase() );
			else
				stringBuffer.append(String.valueOf(chars[index]).toLowerCase() );
		}
		System.out.println(stringBuffer.toString());
		return stringBuffer.toString();
	}
}
