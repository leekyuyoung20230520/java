package spring5.BookRentalPjt.user.member;

import org.springframework.stereotype.Repository;

//@Component   // 단순히 빈을 등록하고 싶은 클래스
@Repository   // 추천  주로 DAO성격에적용 예외처리를 편리하게 할수 있도록 지원  자동예외반환
public class UserMemberDao {

}
