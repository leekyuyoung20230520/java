package spring5.BookRentalPjt.library.book;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class BookDao {

	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public int insertBook(BookVo vo) {
		String sql = "    insert into tbl_book(b_thumbnail,"
				+ "                         b_name		,"
				+ "                         b_author	,"
				+ "                         b_publisher,"
				+ "                         b_publish_year,"
				+ "                         b_isbn			,"
				+ "                         b_call_number	,"
				+ "                         b_rental_able	,"
				+ "                         b_reg_date 	,	"
				+ "                         b_mod_date		"
				+ "                         )"
				+ "                         values( ?,?,?,?,?,?,?,?,now(),now())";
		int result = -1;
		
		try {
			result = jdbcTemplate.update(sql,
					vo.getB_thumbnail(),vo.getB_name(),vo.getB_author(),
					vo.getB_publisher(),vo.getB_publish_year(),vo.getB_isbn(),
					vo.getB_call_number(),vo.getB_rental_able()
					);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
