package spring5.BookRentalPjt.library.book;

public class BookVo {
	private int b_no;			
	private String b_thumbnail;		
	private String b_name;			
	private String b_author;		
	private String b_publisher;		
	private String b_publish_year;
	private String b_isbn;			
	private String b_call_number;	
	private int b_rental_able;	
	private String b_reg_date; 		
	private String b_mod_date;
	public int getB_no() {
		return b_no;
	}
	public void setB_no(int b_no) {
		this.b_no = b_no;
	}
	public String getB_thumbnail() {
		return b_thumbnail;
	}
	public void setB_thumbnail(String b_thumbnail) {
		this.b_thumbnail = b_thumbnail;
	}
	public String getB_name() {
		return b_name;
	}
	public void setB_name(String b_name) {
		this.b_name = b_name;
	}
	public String getB_author() {
		return b_author;
	}
	public void setB_author(String b_author) {
		this.b_author = b_author;
	}
	public String getB_publisher() {
		return b_publisher;
	}
	public void setB_publisher(String b_publisher) {
		this.b_publisher = b_publisher;
	}
	public String getB_publish_year() {
		return b_publish_year;
	}
	public void setB_publish_year(String b_publish_year) {
		this.b_publish_year = b_publish_year;
	}
	public String getB_isbn() {
		return b_isbn;
	}
	public void setB_isbn(String b_isbn) {
		this.b_isbn = b_isbn;
	}
	public String getB_call_number() {
		return b_call_number;
	}
	public void setB_call_number(String b_call_number) {
		this.b_call_number = b_call_number;
	}
	public int getB_rental_able() {
		return b_rental_able;
	}
	public void setB_rental_able(int b_rental_able) {
		this.b_rental_able = b_rental_able;
	}
	public String getB_reg_date() {
		return b_reg_date;
	}
	public void setB_reg_date(String b_reg_date) {
		this.b_reg_date = b_reg_date;
	}
	public String getB_mod_date() {
		return b_mod_date;
	}
	public void setB_mod_date(String b_mod_date) {
		this.b_mod_date = b_mod_date;
	}
	@Override
	public String toString() {
		return "BookVo [b_no=" + b_no + ", b_thumbnail=" + b_thumbnail + ", b_name=" + b_name + ", b_author=" + b_author
				+ ", b_publisher=" + b_publisher + ", b_publish_year=" + b_publish_year + ", b_isbn=" + b_isbn
				+ ", b_call_number=" + b_call_number + ", b_rental_able=" + b_rental_able + ", b_reg_date=" + b_reg_date
				+ ", b_mod_date=" + b_mod_date + "]";
	}
	
}
