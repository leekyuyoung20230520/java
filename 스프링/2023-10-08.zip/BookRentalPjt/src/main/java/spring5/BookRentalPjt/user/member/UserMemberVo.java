package spring5.BookRentalPjt.user.member;

// getter / setter를 대신하는 롬북을 상용  어노테이션을 통해 사용 , 코드를 간결하게 유지
// 

// 주로 테이블단위로 생성 vo객체 하나가 table에 row하나에 대응
public class UserMemberVo {
	private int u_m_no;		// 사용자 번호	
	private String u_m_id;	// 사용자 아이디
	private String u_m_pw;	// 사용자 비밀번호	
	private String u_m_name;	// 사용자 이름
	private String u_m_gender;	// 사용자 성별	
	private String u_m_mail;	// 사용자 메일
	private String u_m_phone;	// 사용자 연락처
	private String u_m_reg_date;	// 사용자 등록일
	private String u_m_mod_date;	// 사용자 수정일	
}
