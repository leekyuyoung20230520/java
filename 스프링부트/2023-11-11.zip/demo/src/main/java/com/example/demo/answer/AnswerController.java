package com.example.demo.answer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.question.Question;
import com.example.demo.question.QuestionService;

import jakarta.validation.Valid;

@Controller
@RequestMapping("/answer")
public class AnswerController {
	@Autowired
	private QuestionService questionService;
	
	@Autowired
	private AnswerService answerService;
	
	@PostMapping("/create/{id}")
	public String answer(Model model, 
			@PathVariable("id") Integer id, @RequestParam String content,
			@Valid AnswerForm answerForm, BindingResult bindingResult) {
		Question question = questionService.detail(id);
		
		if(bindingResult.hasErrors()) {
			model.addAttribute("question",question);
			return "question_detail";
		}
		
		
		answerService.create(question,content);
		return String.format("redirect:/question/detail/%s", id);
	}

}
