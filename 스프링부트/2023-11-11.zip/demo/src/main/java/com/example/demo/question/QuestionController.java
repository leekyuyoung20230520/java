package com.example.demo.question;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.answer.Answer;
import com.example.demo.answer.AnswerForm;

import jakarta.validation.Valid;

//@RequiredArgsConstructor

@Controller
@RequestMapping("/question")
public class QuestionController {
	@Autowired
	private QuestionService questionService;
	
	@GetMapping("/list")
//	@ResponseBody
	public String list(Model model) {
//		return "<h1>question list</h1>";
//		return "question_list";
		List<Question> questionList = questionService.getList();
		model.addAttribute("questionList",questionList);
		return "question_list";
	}
	@GetMapping(value = "/detail/{id}")
	public String detail(Model model,@PathVariable("id") Integer id, AnswerForm answerForm) {
		Question q =  questionService.detail(id);
		model.addAttribute("question",q);		
		return "question_detail";
	}
	
	@GetMapping("/create")
	public String create(QuestionForm questionFrom) {
		return "question_form";
	}	
	
	@PostMapping("/create")
	public String create(@Valid QuestionForm questionFrom, BindingResult bindingResult,
			Principal principal) {
		if(bindingResult.hasErrors())
			return "question_form";
		// 질문을 저장
		questionService.create(questionFrom.getSubject(), questionFrom.getContent());
		// 질문을 저장한 후에는 질문 목록으로 이동
		return "redirect:/question/list";
	}
	
}
