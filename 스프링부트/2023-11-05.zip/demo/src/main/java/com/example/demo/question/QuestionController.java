package com.example.demo.question;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

//@RequiredArgsConstructor

@Controller
@RequestMapping("/question")
public class QuestionController {
	@Autowired
	private QuestionService questionService;
	
	@GetMapping("/list")
//	@ResponseBody
	public String list(Model model) {
//		return "<h1>question list</h1>";
//		return "question_list";
		List<Question> questionList = questionService.getList();
		model.addAttribute("questionList",questionList);
		return "question_list";
	}
	@GetMapping(value = "/detail/{id}")
	public String detail(Model model,@PathVariable("id") Integer id) {
		Question q =  questionService.detail(id);
		model.addAttribute("question",q);		
		return "question_detail";
	}
}
