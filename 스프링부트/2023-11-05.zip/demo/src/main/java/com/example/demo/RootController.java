package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class RootController {

	// redirect : 완전히 새로운 url로 요청이 된다
	// forward : 기존 요청 값들이 유진된 상태로 url이 전환
	@GetMapping
	public String root() {
		return "redirect:/question/list";
	}
}
