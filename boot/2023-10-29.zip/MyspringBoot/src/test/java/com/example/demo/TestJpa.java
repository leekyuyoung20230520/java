package com.example.demo;

import java.time.LocalDateTime;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TestJpa {
	@Autowired
	private QuestionRepository qr;
	
	@Test
	void test1() {
		Question q1 = new Question();
		q1.setSubject("질문 있어요");
		q1.setContent("독도에 가려면 어떻게하나요 그리고 비용은요?");
		q1.setCreateDate(LocalDateTime.now());
		qr.save(q1);
		
		Question q2 = new Question();
		q2.setSubject("질문또 있어요");
		q2.setContent("울릉도는 어떻게 가요? 매일 출항하나요?");
		q2.setCreateDate(LocalDateTime.now());
		qr.save(q2);
		
	}
	
	

}
