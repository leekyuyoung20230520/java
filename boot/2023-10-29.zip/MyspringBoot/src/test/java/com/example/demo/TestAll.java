package com.example.demo;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TestAll {
	@Autowired
	QuestionRepository qr;
	// 전체 조회  select * from question;
		@Test
		void test2() {
			List<Question> all =  qr.findAll();
			System.out.println(all.size());
			System.out.println(  all.get(0).getSubject() );
		}
		
		
		@Test
		void findById() {
			Optional<Question> q =  qr.findById(1);
			System.out.println(q.isPresent());
		}
		
		@Test
		void findBySubject() {
			Optional q =  qr.findBySubject("몰라");
			System.out.println(q);
		}
		
		
}
